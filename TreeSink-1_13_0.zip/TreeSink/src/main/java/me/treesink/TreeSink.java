/*
 * TreeSink
 * Copyright (c) mikaelzer0 - https://github.com/mikaelzer0
 * Tutti i diritti riservati.
 */
package me.treesink;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import io.papermc.paper.event.player.PrePlayerAttackEntityEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Leaves;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.block.data.MultipleFacing;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.event.world.EntitiesUnloadEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.time.Duration;
import java.util.*;

/**
 * TreeSink - analizza l'albero (tronchi, spessore), mostra una barra di rottura sopra la chioma
 * che si riempie a ogni tronco rotto; a barra piena l'albero cade lentamente, le foglie droppano
 * e l'arboscello viene ripiantato. L'ascia si usura in base alla grandezza dell'albero.
 */
public class TreeSink extends JavaPlugin implements Listener, CommandExecutor {

    private static final BlockFace[] FACES = {
            BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH,
            BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST
    };

    private final Set<UUID> disabled = new HashSet<>();
    private final Set<UUID> busy = new HashSet<>();
    private final List<Anim> active = new ArrayList<>();
    private final Map<Block, Session> sessions = new HashMap<>();
    private final Random rnd = new Random();

    private Set<String> worlds = new HashSet<>();
    private boolean requireAxe, sneakDisables, damageTool, replant, respectProtection, showBar, breakAtHit;
    private int maxLogs, maxLeaves, minLeaves, creakTicks;
    private int minHits, maxHits, logsPerHit, thicknessBonusHits, resetSeconds;
    private double fallSpeed, durabilityPerLog, thicknessDurBonus;
    private double handPower, otherToolPower, efficiencyBonus, sharpnessBonus, appleChance, fortuneAppleBonus;
    private final Set<Material> appleLeaves = new HashSet<>();
    private int appleMinPerTree;
    private boolean appleAllTrees;
    private boolean debug;
    // rampicanti (vine) attaccati all'albero
    private boolean removeVines, vinesDropWithSilk, vinesForce;
    // particelle foglie, rami e suoni
    private double leafParticleMult;
    // solo per ripulire i vecchi rami della 1.12 rimasti nel mondo
    private NamespacedKey branchKey, branchPartsKey;
    // effetti speciali
    private boolean fxEnabled, fxSounds, fxParts, fxShake;
    private double fxVolume, fxScale, shakeRadius, shakePower;
    private boolean collisionBreak;
    // danno da caduta
    private boolean fallDamageEnabled;
    private double fallDamage, fallKnockback, fallHitRadius, fallCanopyRadius;
    private final Map<String, Double> toolPowers = new HashMap<>();
    // mele 3D sugli alberi
    private boolean fruitEnabled, fruitSounds, fruitParticles, fruitDropCreative;
    private int fruitCycleSeconds = 10, fruitCycleCounter;
    private int fruitDropAmount, fruitMaxPerTree, fruitMaxTotal, fruitAttempts, fruitRadius;
    private double fruitSpawnChance, fruitSize, fruitHeadScale;
    private String fruitHeadTexture = "";
    private NamespacedKey fruitKey, fruitPartsKey;
    private final Map<UUID, Fruit> fruits = new HashMap<>();

    // ------------------------------------------------------------------ setup

    @Override
    public void onEnable() {
        saveDefaultConfig();
        fruitKey = new NamespacedKey(this, "fruit");
        fruitPartsKey = new NamespacedKey(this, "fruit_parts");
        branchKey = new NamespacedKey(this, "branch");
        branchPartsKey = new NamespacedKey(this, "branch_parts");
        loadSettings();
        getLogger().info("TreeSink v" + getPluginMeta().getVersion() + " by mikaelzer0 - https://github.com/mikaelzer0");
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("treesink") != null) getCommand("treesink").setExecutor(this);
        getServer().getScheduler().runTaskTimer(this, this::expireSessions, 10L, 10L);
        getServer().getScheduler().runTaskTimer(this, this::spawnFruitsCycle, 100L, 20L);
        getServer().getScheduler().runTaskTimer(this, this::validateFruits, 40L, 10L);
        getServer().getScheduler().runTask(this, this::loadExistingFruits);
        getServer().getScheduler().runTask(this, this::cleanLegacyBranches);
    }

    @Override
    public void onDisable() {
        for (Anim a : new ArrayList<>(active)) a.finishAll();
        active.clear();
        for (Session s : sessions.values()) s.remove();
        sessions.clear();
    }

    private void loadSettings() {
        reloadConfig();
        worlds = new HashSet<>(getConfig().getStringList("worlds"));
        requireAxe = getConfig().getBoolean("require-axe", false);
        breakAtHit = getConfig().getBoolean("break-at-hit", true);
        sneakDisables = getConfig().getBoolean("sneak-disables", true);
        removeVines = getConfig().getBoolean("remove-vines", true);
        vinesDropWithSilk = getConfig().getBoolean("vines-drop-with-silk", true);
        vinesForce = getConfig().getBoolean("vines-force-remove", true);
        leafParticleMult = Math.max(0.0, getConfig().getDouble("effects.leaf-particle-multiplier", 3.0));
        damageTool = getConfig().getBoolean("damage-tool", true);
        replant = getConfig().getBoolean("replant", true);
        respectProtection = getConfig().getBoolean("respect-protection", true);
        showBar = getConfig().getBoolean("show-bar", true);
        maxLogs = getConfig().getInt("max-logs", 300);
        maxLeaves = getConfig().getInt("max-leaves", 500);
        minLeaves = getConfig().getInt("min-leaves", 3);
        minHits = Math.max(1, getConfig().getInt("min-hits", 3));
        maxHits = Math.max(minHits, getConfig().getInt("max-hits", 25));
        logsPerHit = Math.max(1, getConfig().getInt("logs-per-hit", 3));
        thicknessBonusHits = Math.max(0, getConfig().getInt("thickness-bonus-hits", 2));
        resetSeconds = Math.max(1, getConfig().getInt("reset-seconds", 10));
        durabilityPerLog = Math.max(0, getConfig().getDouble("durability-per-log", 2.0));
        thicknessDurBonus = Math.max(0, getConfig().getDouble("thickness-durability-bonus", 0.25));
        fallSpeed = Math.max(0.0002, getConfig().getDouble("fall-speed", 0.0016));
        creakTicks = Math.max(0, getConfig().getInt("creak-ticks", 12));

        toolPowers.clear();
        var sec = getConfig().getConfigurationSection("tool-power");
        if (sec != null) {
            for (String k : sec.getKeys(false)) toolPowers.put(k.toUpperCase(Locale.ROOT), Math.max(0.05, sec.getDouble(k, 1.0)));
        }
        appleChance = Math.max(0, Math.min(1, getConfig().getDouble("apple-chance", 0.04)));
        appleLeaves.clear();
        List<String> leafNames = getConfig().getStringList("apple-leaves");
        if (leafNames.isEmpty()) leafNames = List.of("OAK_LEAVES", "DARK_OAK_LEAVES");
        for (String n : leafNames) {
            Material m = Material.matchMaterial(n);
            if (m != null) appleLeaves.add(m);
        }
        appleMinPerTree = Math.max(0, getConfig().getInt("apple-min-per-tree", 1));
        debug = getConfig().getBoolean("log-trees", true);
        appleAllTrees = getConfig().getBoolean("apple-all-trees", true);
        handPower = Math.max(0.02, getConfig().getDouble("hand-power", 0.25));
        otherToolPower = Math.max(0.02, getConfig().getDouble("other-tool-power", 0.3));
        efficiencyBonus = Math.max(0, getConfig().getDouble("efficiency-bonus", 0.25));
        sharpnessBonus = Math.max(0, getConfig().getDouble("sharpness-bonus", 0.05));
        fortuneAppleBonus = Math.max(0, getConfig().getDouble("fortune-apple-bonus", 0.5));

        fxEnabled = getConfig().getBoolean("effects.enabled", true);
        fxSounds = getConfig().getBoolean("effects.sounds", true);
        fxParts = getConfig().getBoolean("effects.particles", true);
        fxShake = getConfig().getBoolean("effects.impact-shake", true);
        fxVolume = Math.max(0.0, getConfig().getDouble("effects.sound-volume", 1.0));
        fxScale = Math.max(0.1, getConfig().getDouble("effects.particle-scale", 1.0));
        shakeRadius = Math.max(0.0, getConfig().getDouble("effects.shake-radius", 8.0));
        shakePower = Math.max(0.0, getConfig().getDouble("effects.shake-power", 1.0));

        collisionBreak = getConfig().getBoolean("collision-break", true);
        fallDamageEnabled = getConfig().getBoolean("fall-damage.enabled", true);
        fallDamage = Math.max(0.0, getConfig().getDouble("fall-damage.damage", 12.0));
        fallKnockback = Math.max(0.0, getConfig().getDouble("fall-damage.knockback", 0.9));
        fallHitRadius = Math.max(0.3, getConfig().getDouble("fall-damage.trunk-radius", 1.3));
        fallCanopyRadius = Math.max(0.0, getConfig().getDouble("fall-damage.canopy-radius", 2.5));

        fruitEnabled = getConfig().getBoolean("fruit.enabled", true);
        fruitSounds = getConfig().getBoolean("fruit.sounds", true);
        fruitParticles = getConfig().getBoolean("fruit.particles", true);
        fruitDropCreative = getConfig().getBoolean("fruit.drop-in-creative", true);
        fruitDropAmount = Math.max(1, getConfig().getInt("fruit.drop-amount", 1));
        fruitMaxPerTree = Math.max(1, getConfig().getInt("fruit.max-per-tree", 3));
        fruitCycleSeconds = Math.max(1, getConfig().getInt("fruit.cycle-seconds", 5));
        fruitMaxTotal = getConfig().getInt("fruit.max-total", 0);
        if (fruitMaxTotal <= 0) fruitMaxTotal = Integer.MAX_VALUE; // 0 = illimitate
        fruitAttempts = Math.max(1, getConfig().getInt("fruit.attempts-per-cycle", 8));
        fruitRadius = Math.max(4, getConfig().getInt("fruit.spawn-radius", 24));
        fruitSpawnChance = Math.max(0.0, Math.min(1.0, getConfig().getDouble("fruit.spawn-chance", 0.25)));
        fruitSize = Math.max(0.5, Math.min(3.0, getConfig().getDouble("fruit.size", 1.0)));
        fruitHeadScale = Math.max(0.1, getConfig().getDouble("fruit.head-scale", 0.6));
        fruitHeadTexture = getConfig().getString("fruit.head-texture", "");
        if (fruitHeadTexture == null) fruitHeadTexture = "";
        fruitHeadTexture = fruitHeadTexture.trim();
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 0 || a[0].equalsIgnoreCase("toggle")) {
            if (!(s instanceof Player p)) {
                s.sendMessage("Solo in gioco.");
                return true;
            }
            if (disabled.remove(p.getUniqueId())) {
                p.sendMessage("§aTreeSink attivato.");
            } else {
                disabled.add(p.getUniqueId());
                p.sendMessage("§cTreeSink disattivato.");
            }
            return true;
        }
        if (a[0].equalsIgnoreCase("reload")) {
            if (!s.hasPermission("treesink.reload")) {
                s.sendMessage("§cNon hai il permesso.");
                return true;
            }
            loadSettings();
            s.sendMessage("§aConfig ricaricata.");
            return true;
        }
        if (a[0].equalsIgnoreCase("fruits")) {
            if (!s.hasPermission("treesink.reload")) {
                s.sendMessage("§cNon hai il permesso.");
                return true;
            }
            if (!(s instanceof Player p)) {
                s.sendMessage("Solo in gioco.");
                return true;
            }
            if (!fruitEnabled) {
                s.sendMessage("§cLe mele sono disattivate nella config (fruit.enabled).");
                return true;
            }
            int n = spawnFruitsAround(p, 300, 1.0);
            s.sendMessage("§aMele create: §f" + n + " §7(totali caricate: " + fruits.size() + ")");
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ evento

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        if (busy.contains(id) || disabled.contains(id)) return;
        if (!p.hasPermission("treesink.use")) return;
        if (sneakDisables && p.isSneaking()) return;

        GameMode gm = p.getGameMode();
        if (gm == GameMode.ADVENTURE || gm == GameMode.SPECTATOR) return;

        Block origin = e.getBlock();
        if (!Tag.LOGS.isTagged(origin.getType())) return;
        if (!worlds.isEmpty() && !worlds.contains(origin.getWorld().getName())) return;

        ItemStack tool = p.getInventory().getItemInMainHand();
        if (requireAxe && !tool.getType().name().endsWith("_AXE")) return;

        // --- analisi dell'albero intero
        Tree whole = scan(origin);
        if (whole == null) return;

        int groundY = minY(whole.logs);
        List<Block> baseBlocks = baseOf(whole.logs, groundY);
        if (baseBlocks.isEmpty()) return; // non e' un albero naturale -> rottura normale

        // --- punto di rottura: l'albero si spezza all'altezza del tronco colpito.
        // Cade solo la parte da li' in su; sotto resta il ceppo. Meno tronchi da abbattere = meno colpi.
        int cutY = breakAtHit ? Math.max(groundY, origin.getY()) : groundY;
        Tree tree = whole;
        List<Block> trunk = baseBlocks;
        if (cutY > groundY) {
            tree = upperPart(whole, origin, cutY);
            trunk = trunkAt(tree, origin);
        }

        boolean survival = gm == GameMode.SURVIVAL;

        // creativa: abbattimento istantaneo, niente barra
        if (!survival) {
            if (fell(p, tool, origin, tree, false, groundY, cutY, trunk)) e.setCancelled(true);
            return;
        }

        // --- sessione di rottura (barra sopra l'albero); una per ogni altezza di rottura
        Block key = trunk.stream()
                .min(Comparator.comparingInt(Block::getX).thenComparingInt(Block::getZ)).get();
        final double power = toolPower(tool);
        Session s = sessions.get(key);

        if (s == null) {
            int logs = tree.logs.size();
            int thick = thickness(tree.logs, cutY);
            int req = ceilDiv(logs, logsPerHit) + (thick - 1) * thicknessBonusHits;
            req = Math.max(minHits, Math.min(maxHits, req));
            int total = damageTool && isTool(tool)
                    ? Math.max(1, (int) Math.ceil(logs * durabilityPerLog * (1 + (thick - 1) * thicknessDurBonus)))
                    : 0;

            if (damageTool) {
                // mai rifiutare l'abbattimento: se l'attrezzo e' quasi rotto l'usura viene limitata
                int left = durabilityLeft(tool);
                if (left != Integer.MAX_VALUE) total = Math.max(0, Math.min(total, left - 1));
            }

            s = new Session(key.getWorld(), key, treeName(origin.getType()), logs, thick, req, total);
            s.power = power;
            s.toolLabel = toolLabel(tool);
            s.canopy = canopyOf(tree, key.getWorld());
            s.leafSample = tree.leaves.isEmpty() ? null : tree.leaves.iterator().next().getBlockData();
            if (showBar) s.createBar();
            sessions.put(key, s);
        }

        e.setCancelled(true);
        s.power = power;
        s.toolLabel = toolLabel(tool);
        s.progress += power;
        s.lastHit = System.currentTimeMillis();
        s.hitBlocks.add(origin.getLocation());

        ItemStack dropTool = tool.clone();
        double ratio = Math.min(1.0, s.progress / (double) s.required);
        if (damageTool && s.totalDamage > 0) {
            int done = (int) Math.round(s.totalDamage * ratio);
            int dmg = done - s.damageDone;
            s.damageDone = done;
            applyDamage(p, tool, dmg);
        }

        hitFx(p, s, origin, ratio);

        if (s.progress >= s.required - 1e-9) {
            sessions.remove(key);
            s.remove();
            finalFx(p, s, origin);
            fell(p, dropTool, origin, tree, true, groundY, cutY, trunk);
        } else {
            s.update(p);
            p.sendBlockDamage(origin.getLocation(), (float) ratio);
        }
    }

    /** Controllo protezioni + avvio animazione. Ritorna false se non e' possibile abbattere. */
    private boolean fell(Player p, ItemStack tool, Block origin, Tree tree, boolean survival,
                         int groundY, int cutY, List<Block> trunk) {
        UUID id = p.getUniqueId();
        if (respectProtection) {
            busy.add(id);
            try {
                tree.logs.removeIf(b -> !b.equals(origin) && !allowed(p, b));
                tree.leaves.removeIf(b -> !allowed(p, b));
            } finally {
                busy.remove(id);
            }
        }
        if (tree.logs.isEmpty()) return false;
        if (cutY <= groundY) {
            // rottura alla base: tutto l'albero cade (come prima)
            groundY = minY(tree.logs);
            cutY = groundY;
            trunk = baseOf(tree.logs, groundY);
        } else {
            trunk = new ArrayList<>(trunk);
            trunk.removeIf(b -> !tree.logs.contains(b));
        }
        if (trunk.isEmpty()) return false;
        startAnimation(p, tool, origin.getType(), tree, trunk, groundY, cutY, survival);
        return true;
    }

    /** Parte dell'albero dal punto di rottura in su: tronchi collegati al blocco colpito (quota >= cutY) e foglie sopra. */
    private Tree upperPart(Tree whole, Block origin, int cutY) {
        Set<Block> logs = new LinkedHashSet<>();
        Deque<Block> q = new ArrayDeque<>();
        logs.add(origin);
        q.add(origin);
        while (!q.isEmpty()) {
            Block b = q.poll();
            for (int dx = -1; dx <= 1; dx++)
                for (int dy = -1; dy <= 1; dy++)
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        Block n = b.getRelative(dx, dy, dz);
                        if (n.getY() >= cutY && whole.logs.contains(n) && logs.add(n)) q.add(n);
                    }
        }
        Set<Block> leaves = new LinkedHashSet<>();
        for (Block l : whole.leaves) if (l.getY() >= cutY) leaves.add(l);
        return new Tree(logs, leaves);
    }

    /** Tronchi dello strato di rottura attorno al blocco colpito (1 tronco, o 2x2 per gli alberi giganti). */
    private List<Block> trunkAt(Tree tree, Block origin) {
        List<Block> list = new ArrayList<>();
        for (Block b : tree.logs) {
            if (b.getY() == origin.getY()
                    && Math.abs(b.getX() - origin.getX()) <= 1
                    && Math.abs(b.getZ() - origin.getZ()) <= 1) list.add(b);
        }
        return list;
    }

    private boolean allowed(Player p, Block b) {
        BlockBreakEvent ev = new BlockBreakEvent(b, p);
        ev.setDropItems(false);
        ev.setExpToDrop(0);
        getServer().getPluginManager().callEvent(ev);
        return !ev.isCancelled();
    }

    // ------------------------------------------------------------------ analisi

    private static class Tree {
        final Set<Block> logs;
        final Set<Block> leaves;

        Tree(Set<Block> logs, Set<Block> leaves) {
            this.logs = logs;
            this.leaves = leaves;
        }
    }

    private Tree scan(Block origin) {
        Material type = origin.getType();

        Set<Block> logs = new LinkedHashSet<>();
        Deque<Block> q = new ArrayDeque<>();
        logs.add(origin);
        q.add(origin);
        while (!q.isEmpty()) {
            Block b = q.poll();
            for (int dx = -1; dx <= 1; dx++)
                for (int dy = -1; dy <= 1; dy++)
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        Block n = b.getRelative(dx, dy, dz);
                        if (n.getType() == type && logs.add(n)) {
                            if (logs.size() > maxLogs) return null; // troppo grande: costruzione?
                            q.add(n);
                        }
                    }
        }

        Set<Block> leaves = new LinkedHashSet<>();
        Deque<Block> lq = new ArrayDeque<>();
        for (Block l : logs) {
            for (BlockFace f : FACES) {
                Block n = l.getRelative(f);
                if (naturalLeaf(n) && leaves.add(n)) lq.add(n);
            }
        }
        while (!lq.isEmpty() && leaves.size() < maxLeaves) {
            Block b = lq.poll();
            int dist = ((Leaves) b.getBlockData()).getDistance();
            for (BlockFace f : FACES) {
                Block n = b.getRelative(f);
                if (naturalLeaf(n) && ((Leaves) n.getBlockData()).getDistance() > dist && leaves.add(n)) {
                    lq.add(n);
                }
            }
        }

        if (leaves.size() < minLeaves) return null;
        return new Tree(logs, leaves);
    }

    // ------------------------------------------------------------------ pulizia vecchi rami

    /** I rami della 1.12 non esistono piu': se ne restano nel mondo, i loro display vengono eliminati. */
    private void purgeLegacyBranches(Collection<? extends Entity> entities) {
        Set<UUID> kill = new HashSet<>();
        for (Entity en : entities) {
            if (!(en instanceof BlockDisplay)) continue;
            PersistentDataContainer pdc = en.getPersistentDataContainer();
            if (!pdc.has(branchKey, PersistentDataType.INTEGER_ARRAY)) continue;
            kill.add(en.getUniqueId());
            for (String sp : pdc.getOrDefault(branchPartsKey, PersistentDataType.STRING, "").split(",")) {
                if (sp.isBlank()) continue;
                try {
                    kill.add(UUID.fromString(sp.trim()));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
        if (kill.isEmpty()) return;
        for (Entity en : entities) if (kill.contains(en.getUniqueId())) en.remove();
    }

    private void cleanLegacyBranches() {
        for (World w : Bukkit.getWorlds()) purgeLegacyBranches(w.getEntitiesByClass(BlockDisplay.class));
    }

    // ------------------------------------------------------------------ rampicanti

    /** Il rampicante regge ancora? (blocco pieno su una sua faccia, oppure rampicante sopra con la stessa faccia) */
    private boolean vineSupported(Block v) {
        if (!(v.getBlockData() instanceof MultipleFacing mf)) return true;
        Block above = v.getRelative(BlockFace.UP);
        for (BlockFace f : mf.getFaces()) {
            if (v.getRelative(f).getType().isOccluding()) return true;
            if (f != BlockFace.UP && above.getType() == Material.VINE
                    && above.getBlockData() instanceof MultipleFacing am && am.hasFace(f)) return true;
        }
        return false;
    }

    /**
     * Dopo che l'albero e' stato tolto, i rampicanti (vine) rimasti senza appoggio spariscono con lui
     * invece di restare sospesi a mezz'aria. Quelli appoggiati a blocchi che restano (muri, altri alberi) non si toccano.
     */
    private void removeVines(Player p, Tree tree, boolean dropVines, World w) {
        if (!removeVines) return;
        Set<Block> candidates = new LinkedHashSet<>();
        Deque<Block> q = new ArrayDeque<>();
        for (Collection<Block> part : List.of(tree.logs, tree.leaves)) {
            for (Block b : part) {
                // anche in diagonale: le liane che sfiorano l'albero spariscono con lui
                for (int dx = -1; dx <= 1; dx++)
                    for (int dy = -1; dy <= 1; dy++)
                        for (int dz = -1; dz <= 1; dz++) {
                            if (dx == 0 && dy == 0 && dz == 0) continue;
                            Block n = b.getRelative(dx, dy, dz);
                            if (n.getType() == Material.VINE && candidates.add(n)) q.add(n);
                        }
            }
        }
        // le catene di rampicanti che pendono verso il basso
        while (!q.isEmpty() && candidates.size() < 600) {
            Block below = q.poll().getRelative(BlockFace.DOWN);
            if (below.getType() == Material.VINE && candidates.add(below)) q.add(below);
        }
        if (candidates.isEmpty()) return;

        List<Block> ordered = new ArrayList<>(candidates);
        ordered.sort(Comparator.comparingInt(Block::getY).reversed()); // dall'alto: cadendo la catena si svuota
        UUID id = p.getUniqueId();
        int removed = 0;
        busy.add(id);
        try {
            boolean changed = true;
            for (int pass = 0; changed && pass < 8; pass++) {
                changed = false;
                for (Block v : ordered) {
                    if (v.getType() != Material.VINE || (!vinesForce && vineSupported(v))) continue;
                    if (respectProtection && !allowed(p, v)) continue;
                    BlockData data = v.getBlockData();
                    Location at = v.getLocation().add(0.5, 0.5, 0.5);
                    v.setType(Material.AIR, false);
                    if (dropVines) w.dropItemNaturally(at, new ItemStack(Material.VINE));
                    if (removed++ % 3 == 0) {
                        fxPart(w, Particle.BLOCK, at, 6, 0.3, 0.3, 0.3, 0, data);
                        fxSound(w, at, Sound.BLOCK_VINE_BREAK, 0.5f, 0.9f + rnd.nextFloat() * 0.3f);
                    }
                    changed = true;
                }
            }
        } finally {
            busy.remove(id);
        }
    }

    private boolean naturalLeaf(Block b) {
        if (!Tag.LEAVES.isTagged(b.getType())) return false;
        return b.getBlockData() instanceof Leaves l && !l.isPersistent();
    }

    private int minY(Set<Block> logs) {
        int m = Integer.MAX_VALUE;
        for (Block b : logs) m = Math.min(m, b.getY());
        return m;
    }

    /** Tronchi dello strato piu' basso appoggiati su terra. */
    private List<Block> baseOf(Set<Block> logs, int minY) {
        List<Block> base = new ArrayList<>();
        for (Block b : logs) {
            if (b.getY() == minY && Tag.DIRT.isTagged(b.getRelative(BlockFace.DOWN).getType())) base.add(b);
        }
        return base;
    }

    /** Spessore: numero massimo di tronchi in uno dei 3 strati piu' bassi (1 = tronco singolo, 4 = 2x2...). */
    private int thickness(Set<Block> logs, int minY) {
        int best = 1;
        for (int y = minY; y <= minY + 2; y++) {
            int c = 0;
            for (Block b : logs) if (b.getY() == y) c++;
            best = Math.max(best, c);
        }
        return best;
    }

    /**
     * Potenza dell'attrezzo: piu' e' bassa, piu' colpi servono.
     * Asce per materiale; altri attrezzi (piccone, pala, zappa, spada) piu' deboli; mano e oggetti
     * non idonei i piu' deboli. Efficienza e Affilatura la aumentano.
     */
    private double toolPower(ItemStack tool) {
        String n = tool.getType().name();
        double pw;
        if (n.endsWith("_AXE")) {
            pw = toolPowers.getOrDefault(n.substring(0, n.length() - 4), 1.0);
        } else if (n.endsWith("_PICKAXE") || n.endsWith("_SHOVEL") || n.endsWith("_HOE")
                || n.endsWith("_SWORD") || n.equals("MACE")) {
            pw = otherToolPower;
        } else {
            pw = handPower;
        }
        int eff = tool.getEnchantmentLevel(Enchantment.EFFICIENCY);
        int sharp = tool.getEnchantmentLevel(Enchantment.SHARPNESS);
        pw *= 1 + eff * efficiencyBonus + sharp * sharpnessBonus;
        return Math.max(0.02, pw);
    }

    private String toolLabel(ItemStack tool) {
        String n = tool.getType().name();
        if (tool.getType().isAir()) return "Mano";
        if (!n.endsWith("_AXE")) return "Altro attrezzo";
        return switch (n.substring(0, n.length() - 4)) {
            case "WOODEN" -> "Ascia di legno";
            case "STONE" -> "Ascia di pietra";
            case "COPPER" -> "Ascia di rame";
            case "IRON" -> "Ascia di ferro";
            case "GOLDEN" -> "Ascia d'oro";
            case "DIAMOND" -> "Ascia di diamante";
            case "NETHERITE" -> "Ascia di netherite";
            default -> "Ascia";
        };
    }

    /** Centro approssimativo della chioma (per le particelle di foglie). */
    private Location canopyOf(Tree tree, World w) {
        if (tree.leaves.isEmpty()) return null;
        double x = 0, y = 0, z = 0;
        for (Block b : tree.leaves) {
            x += b.getX() + 0.5;
            y += b.getY() + 0.5;
            z += b.getZ() + 0.5;
        }
        int n = tree.leaves.size();
        return new Location(w, x / n, y / n, z / n);
    }

    private String treeName(Material m) {
        String n = m.name();
        if (n.startsWith("DARK_OAK")) return "Quercia scura";
        if (n.startsWith("PALE_OAK")) return "Quercia pallida";
        if (n.startsWith("OAK")) return "Quercia";
        if (n.startsWith("SPRUCE")) return "Abete";
        if (n.startsWith("BIRCH")) return "Betulla";
        if (n.startsWith("JUNGLE")) return "Albero della giungla";
        if (n.startsWith("ACACIA")) return "Acacia";
        if (n.startsWith("CHERRY")) return "Ciliegio";
        if (n.startsWith("MANGROVE")) return "Mangrovia";
        return "Albero";
    }

    private static int ceilDiv(int a, int b) {
        return (a + b - 1) / b;
    }

    // ------------------------------------------------------------------ effetti speciali

    private void fxSound(World w, Location l, Sound snd, float vol, float pitch) {
        if (!fxEnabled || !fxSounds) return;
        w.playSound(l, snd, vol * (float) fxVolume, pitch);
    }

    private void fxPart(World w, Particle part, Location l, int n, double dx, double dy, double dz, double speed, Object data) {
        if (!fxEnabled || !fxParts) return;
        int c = Math.max(1, (int) Math.round(n * fxScale));
        w.spawnParticle(part, l, c, dx, dy, dz, speed, data);
    }

    private void fxPart(World w, Particle part, Location l, int n, double dx, double dy, double dz, double speed) {
        fxPart(w, part, l, n, dx, dy, dz, speed, null);
    }

    /** Effetti di ogni colpo: suono base + (se attivi) schegge, scintille, crepe a 25/50/75%. */
    private void hitFx(Player p, Session s, Block origin, double ratio) {
        World w = origin.getWorld();
        Location center = origin.getLocation().add(0.5, 0.5, 0.5);
        BlockData bd = origin.getBlockData();
        float r = (float) ratio;

        w.playSound(center, Sound.BLOCK_WOOD_BREAK, 0.9f, 0.6f + r * 0.6f);
        w.spawnParticle(Particle.BLOCK, center, 10, 0.3, 0.3, 0.3, bd);
        // la chioma si scuote e perde qualche foglia
        if (s.leafSample != null && s.canopy != null) {
            w.spawnParticle(Particle.BLOCK, s.canopy, (int) Math.round(24 * leafParticleMult), 1.6, 1.1, 1.6, 0.02, s.leafSample);
            w.spawnParticle(Particle.FALLING_DUST, s.canopy, (int) Math.round(10 * leafParticleMult), 1.6, 1.0, 1.6, 0.0, s.leafSample);
            w.playSound(s.canopy, Sound.BLOCK_GRASS_HIT, 0.5f, 0.8f + rnd.nextFloat() * 0.3f);
        }
        if (!fxEnabled) return;

        // "thock" di legno a piu' strati: il tono sale man mano che l'albero cede
        fxSound(w, center, Sound.BLOCK_NETHER_WOOD_HIT, 0.9f, 0.6f + r * 0.4f);
        fxSound(w, center, Sound.BLOCK_WOOD_HIT, 0.7f, 0.5f);
        fxSound(w, center, Sound.BLOCK_CHERRY_WOOD_HIT, 0.9f, 0.55f + r * 0.3f);   // colpo sordo e pieno
        fxSound(w, center, Sound.BLOCK_BAMBOO_WOOD_HIT, 0.5f, 0.8f + rnd.nextFloat() * 0.2f); // "tock" secco

        // schegge che schizzano verso chi colpisce (count 0 = il vettore e' la direzione)
        Vector toward = p.getEyeLocation().toVector().subtract(center.toVector());
        if (fxParts && toward.lengthSquared() > 1e-6) {
            toward.normalize();
            int n = Math.max(1, (int) Math.round(6 * fxScale));
            for (int i = 0; i < n; i++) {
                w.spawnParticle(Particle.BLOCK, center, 0,
                        toward.getX() + (rnd.nextDouble() - 0.5) * 0.6,
                        toward.getY() + 0.3 + rnd.nextDouble() * 0.4,
                        toward.getZ() + (rnd.nextDouble() - 0.5) * 0.6, 0.5, bd);
            }
        }

        // chioma: fruscio e, per il ciliegio, una pioggia di petali
        if (s.canopy != null && s.leafSample != null) {
            Material lm = s.leafSample.getMaterial();
            if (lm == Material.CHERRY_LEAVES) {
                fxSound(w, s.canopy, Sound.BLOCK_CHERRY_LEAVES_BREAK, 0.6f, 0.9f);
                fxPart(w, Particle.CHERRY_LEAVES, s.canopy, 12, 1.6, 1.0, 1.6, 0);
            } else {
                fxSound(w, s.canopy, Sound.BLOCK_AZALEA_LEAVES_BREAK, 0.6f, 0.8f + rnd.nextFloat() * 0.3f);
            }
        }

        // crepe a 25 / 50 / 75%: il tronco scricchiola sempre piu' forte
        int step = (int) (ratio * 4);
        if (step > s.milestone && step < 4) {
            s.milestone = step;
            fxSound(w, center, Sound.ENTITY_ZOMBIE_ATTACK_WOODEN_DOOR, 0.7f, 0.45f + step * 0.1f);
            fxSound(w, center, Sound.BLOCK_WOOD_BREAK, 1.2f, 0.4f);
            fxPart(w, Particle.BLOCK, center, 30, 0.4, 0.5, 0.4, 0.15, bd);
        }
    }

    /** Ultimo colpo: schianto del legno, esplosione di schegge e titolo TIMBER!. */
    private void finalFx(Player p, Session s, Block origin) {
        if (!fxEnabled) return;
        World w = origin.getWorld();
        Location center = origin.getLocation().add(0.5, 0.5, 0.5);
        BlockData bd = origin.getBlockData();
        fxSound(w, center, Sound.ENTITY_ZOMBIE_BREAK_WOODEN_DOOR, 0.9f, 0.6f);
        fxSound(w, center, Sound.ENTITY_GENERIC_EXPLODE, 0.3f, 1.6f);
        fxSound(w, center, Sound.BLOCK_CHERRY_WOOD_BREAK, 1.1f, 0.5f);
        fxSound(w, center, Sound.BLOCK_BAMBOO_WOOD_BREAK, 0.8f, 0.7f);
        fxPart(w, Particle.BLOCK, center, 50, 0.5, 0.6, 0.5, 0.2, bd);
    }

    /** Durante la caduta: fruscio d'aria dalla punta dell'albero. */
    private void fallFx(Anim anim, float theta, int height, int t) {
        if (!fxEnabled) return;
        Quaternionf q = new Quaternionf(new AxisAngle4f(theta, anim.fz, 0f, -anim.fx));
        Vector3f v = q.transform(new Vector3f(0f, height + 0.5f, 0f));
        Location tip = new Location(anim.world, anim.px + v.x, anim.py + v.y - anim.curDrop, anim.pz + v.z);
        float prog = theta / (float) (Math.PI / 2);
        if (t % 4 == 0) {
            fxSound(anim.world, tip, Sound.BLOCK_GRASS_HIT, 0.5f + prog * 0.6f, 0.5f + prog * 0.6f);
            // il fogliame che frusta l'aria: sempre piu' forte
            fxSound(anim.world, tip, Sound.BLOCK_AZALEA_LEAVES_HIT, 0.5f + prog * 0.7f, 0.7f + rnd.nextFloat() * 0.3f);
        }
        if (t % 6 == 0) {
            fxSound(anim.world, tip, Sound.BLOCK_GRASS_BREAK, 0.3f + prog * 0.5f, 0.6f + prog * 0.3f);
        }
        if (t % 10 == 0) {
            // lunghi scricchiolii del tronco sotto sforzo
            fxSound(anim.world, anim.hinge, Sound.BLOCK_WOOD_STEP, 0.6f, 0.5f + prog * 0.4f);
        }
    }

    /**
     * Danno a chi si trova sulla traiettoria dell'albero: tronco (asse) e chioma.
     * Ogni creatura viene colpita una sola volta per albero.
     */
    private void fallDamage(Anim anim, float theta, int height) {
        if (!fallDamageEnabled || fallDamage <= 0 || theta < 0.12f) return;
        Quaternionf q = new Quaternionf(new AxisAngle4f(theta, anim.fz, 0f, -anim.fx));
        List<Location> pts = new ArrayList<>();
        List<Double> radii = new ArrayList<>();
        for (int h = 0; h <= height + 1; h++) {
            Vector3f v = q.transform(new Vector3f(0f, h + 0.5f, 0f));
            pts.add(new Location(anim.world, anim.px + v.x, anim.py + v.y - anim.curDrop, anim.pz + v.z));
            radii.add(fallHitRadius);
        }
        if (anim.canopyRel != null && fallCanopyRadius > 0) {
            Vector3f v = q.transform(new Vector3f(anim.canopyRel));
            pts.add(new Location(anim.world, anim.px + v.x, anim.py + v.y - anim.curDrop, anim.pz + v.z));
            radii.add(fallCanopyRadius);
        }
        for (int i = 0; i < pts.size(); i++) {
            Location c = pts.get(i);
            double r = radii.get(i);
            for (Entity en : anim.world.getNearbyEntities(c, r, r, r)) {
                if (!(en instanceof org.bukkit.entity.LivingEntity le)) continue;
                if (en instanceof org.bukkit.entity.ArmorStand) continue;
                if (en instanceof Player pl && pl.getGameMode() == GameMode.SPECTATOR) continue;
                if (!anim.struck.add(en.getUniqueId())) continue;

                double dmg = fallDamage * anim.dmgScale;
                if (anim.cutter != null && anim.cutter.isOnline()) le.damage(dmg, anim.cutter);
                else le.damage(dmg);

                Vector push = new Vector(anim.fx, 0, anim.fz).multiply(fallKnockback);
                push.setY(0.35 * Math.min(1.0, fallKnockback));
                le.setVelocity(le.getVelocity().add(push));

                Location at = le.getLocation().add(0, le.getHeight() / 2.0, 0);
                anim.world.playSound(at, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 0.6f);
                anim.world.playSound(at, Sound.BLOCK_WOOD_BREAK, 1.2f, 0.5f);
                anim.world.spawnParticle(Particle.BLOCK, at, 20, 0.3, 0.4, 0.3, 0.1, Material.OAK_LOG.createBlockData());
            }
        }
    }

    /** Impatto a terra: botto, onda lungo il tronco, anello d'urto e (opzionale) tremolio per i vicini. */
    private void impactFx(Anim anim, int height) {
        if (!fxEnabled) return;
        final World w = anim.world;
        BlockData ground = anim.base.clone().subtract(0, 1, 0).getBlock().getBlockData();
        if (ground.getMaterial().isAir()) ground = Material.DIRT.createBlockData();
        final BlockData gd = ground;
        final Location tip = anim.landing(height);
        final Location mid = anim.landing(height / 2);

        fxSound(w, mid, Sound.ENTITY_GENERIC_EXPLODE, 0.55f, 0.5f);
        fxSound(w, mid, Sound.BLOCK_GRAVEL_BREAK, 1.2f, 0.5f);
        fxSound(w, tip, Sound.BLOCK_WOOD_FALL, 1.4f, 0.45f);
        // botto profondo + schianto di rami e foglie sul terreno
        fxSound(w, mid, Sound.ENTITY_IRON_GOLEM_DAMAGE, 0.5f, 0.5f);
        fxSound(w, mid, Sound.BLOCK_CHERRY_WOOD_BREAK, 1.3f, 0.45f);
        fxSound(w, tip, Sound.BLOCK_AZALEA_LEAVES_BREAK, 1.4f, 0.6f);
        fxSound(w, tip, Sound.BLOCK_GRASS_BREAK, 1.5f, 0.55f);
        fxSound(w, tip, Sound.BLOCK_BAMBOO_WOOD_BREAK, 1.0f, 0.8f);
        // il tronco rimbalza e si assesta: due colpi sempre piu' piccoli, poi il fruscio delle foglie
        getServer().getScheduler().runTaskLater(this, () -> {
            fxSound(w, mid, Sound.BLOCK_WOOD_FALL, 0.8f, 0.7f);
            fxSound(w, mid, Sound.BLOCK_GRAVEL_STEP, 0.7f, 0.6f);
        }, 4L);
        getServer().getScheduler().runTaskLater(this, () -> {
            fxSound(w, mid, Sound.BLOCK_WOOD_HIT, 0.6f, 0.8f);
            fxSound(w, tip, Sound.BLOCK_AZALEA_LEAVES_FALL, 0.9f, 0.8f);
        }, 9L);
        getServer().getScheduler().runTaskLater(this, () -> {
            fxSound(w, tip, Sound.BLOCK_AZALEA_LEAVES_HIT, 0.7f, 0.9f);
            fxSound(w, tip, Sound.BLOCK_GRASS_STEP, 0.6f, 0.7f);
        }, 15L);

        // onda d'urto lungo il tronco: dalla base alla punta
        for (int dy = 0; dy <= height; dy += 2) {
            final int d = dy;
            getServer().getScheduler().runTaskLater(this, () -> {
                Location at = anim.landing(d).add(0, 0.3, 0);
                if (d % 4 == 0) fxSound(w, at, Sound.BLOCK_GRAVEL_BREAK, 0.7f, 0.6f + rnd.nextFloat() * 0.3f);
            }, Math.max(1, dy / 2));
        }

        // tremolio: un piccolo balzo per i giocatori vicini che stanno a terra
        if (fxShake && shakeRadius > 0 && shakePower > 0) {
            for (Player pl : w.getNearbyPlayers(mid, shakeRadius)) {
                if (!pl.getLocation().subtract(0, 0.2, 0).getBlock().getType().isSolid()) continue;
                double f = 1.0 - Math.min(1.0, pl.getLocation().distance(mid) / shakeRadius);
                pl.setVelocity(pl.getVelocity().add(new Vector(0, 0.05 + 0.2 * f * shakePower, 0)));
            }
        }
    }

    // ------------------------------------------------------------------ barra di rottura

    private class Session {
        final World world;
        final Block key;
        final String name;
        final int logs, thickness, required, totalDamage;
        final Set<Location> hitBlocks = new HashSet<>();
        double progress;
        double power = 1.0;
        String toolLabel;
        int damageDone;
        int milestone;
        Location canopy;
        BlockData leafSample;
        long lastHit = System.currentTimeMillis();
        BossBar bar;

        Session(World world, Block key, String name, int logs, int thickness, int required, int totalDamage) {
            this.world = world;
            this.key = key;
            this.name = name;
            this.logs = logs;
            this.thickness = thickness;
            this.required = required;
            this.totalDamage = totalDamage;
        }

        void createBar() {
            bar = Bukkit.createBossBar("", BarColor.GREEN, BarStyle.SOLID);
            bar.setProgress(1.0);
        }

        /** Barra stile boss: parte piena e scende a ogni colpo. */
        void update(Player hitter) {
            if (bar == null) return;
            double ratio = Math.min(1.0, progress / (double) required);
            double left = Math.max(0.0, Math.min(1.0, 1.0 - ratio));
            bar.setProgress(left);
            bar.setColor(left > 0.5 ? BarColor.GREEN : left > 0.2 ? BarColor.YELLOW : BarColor.RED);
            bar.addPlayer(hitter);
        }

        void remove() {
            if (bar != null) {
                bar.removeAll();
                bar.setVisible(false);
            }
            for (Location loc : hitBlocks) {
                for (Player pl : world.getPlayers()) pl.sendBlockDamage(loc, 0f);
            }
        }
    }

    private void expireSessions() {
        long now = System.currentTimeMillis();
        Iterator<Session> it = sessions.values().iterator();
        while (it.hasNext()) {
            Session s = it.next();
            if (now - s.lastHit > resetSeconds * 1000L) {
                s.remove();
                it.remove();
            }
        }
    }

    // ------------------------------------------------------------------ ascia

    /** Solo gli utensili si usurano: asce, picconi, pale, zappe, spade, mazze, cesoie. Mai altri oggetti. */
    private boolean isTool(ItemStack tool) {
        String n = tool.getType().name();
        return n.endsWith("_AXE") || n.endsWith("_PICKAXE") || n.endsWith("_SHOVEL") || n.endsWith("_HOE")
                || n.endsWith("_SWORD") || n.equals("MACE") || n.equals("SHEARS");
    }

    private int durabilityLeft(ItemStack tool) {
        ItemMeta m = tool.getItemMeta();
        if (m instanceof Damageable dm && !m.isUnbreakable()) {
            return tool.getType().getMaxDurability() - dm.getDamage();
        }
        return Integer.MAX_VALUE;
    }

    private void applyDamage(Player p, ItemStack tool, int points) {
        if (!isTool(tool)) return;
        ItemMeta m = tool.getItemMeta();
        if (!(m instanceof Damageable dm) || m.isUnbreakable() || points <= 0) return;

        int lvl = tool.getEnchantmentLevel(Enchantment.UNBREAKING);
        int dmg = 0;
        for (int i = 0; i < points; i++) {
            if (lvl <= 0 || rnd.nextInt(lvl + 1) == 0) dmg++;
        }
        if (dmg <= 0) return;

        int nd = dm.getDamage() + dmg;
        if (nd >= tool.getType().getMaxDurability()) {
            p.getInventory().setItemInMainHand(null);
            p.getWorld().playSound(p.getLocation(), "entity.item.break", 1f, 1f);
            return;
        }
        dm.setDamage(nd);
        tool.setItemMeta(dm);
        p.getInventory().setItemInMainHand(tool);
    }

    // ------------------------------------------------------------------ animazione

    private static class Group {
        final List<BlockDisplay> displays = new ArrayList<>();
        final List<ItemStack> drops = new ArrayList<>();
        BlockData sample;
        BlockData leafData;
        boolean done;
        int dy;
    }

    private class Anim {
        World world;
        Location base;                 // dove finisce a terra l'inizio del tronco abbattuto
        Location hinge;                // punto di rottura (suoni e schegge dello scricchiolio)
        double gy;                     // quota del suolo
        double drop;                   // di quanto scende il pezzo dopo essersi sdraiato (rottura in alto)
        double curDrop;                // discesa attuale (per gli effetti)
        double px, py, pz;             // perno della rotazione (alla base, o sul ceppo se rotto in alto)
        float fx, fz;                  // direzione di caduta (orizzontale, unitaria)
        List<Block> spots = new ArrayList<>();
        Material sapling;
        TreeMap<Integer, Group> groups = new TreeMap<>();
        List<BlockDisplay> leafDisplays = new ArrayList<>();
        int apples;
        Player cutter;
        double dmgScale = 1.0;
        Vector3f canopyRel;            // chioma rispetto al perno (non ruotata)
        final Set<UUID> struck = new HashSet<>();

        Group group(int dy) {
            return groups.computeIfAbsent(dy, k -> new Group());
        }

        /** Dove finisce a terra il pezzo che stava a quota dy: lungo la direzione di caduta. */
        Location landing(int dy) {
            return new Location(world, px + fx * (dy + 0.5), gy + 0.3, pz + fz * (dy + 0.5));
        }

        void finishGroup(Group g) {
            if (g.done) return;
            g.done = true;
            for (BlockDisplay d : g.displays) if (d.isValid()) d.remove();

            Location at = landing(g.dy);
            for (ItemStack it : merge(g.drops)) {
                world.dropItemNaturally(base.clone().add(0, 0.6, 0), it);
            }
            if (g.sample != null) {
                if (g.dy % 3 == 0) {
                    Sound snd = Tag.LEAVES.isTagged(g.sample.getMaterial())
                            ? Sound.BLOCK_GRASS_BREAK : Sound.BLOCK_WOOD_BREAK;
                    world.playSound(at, snd, 0.6f, 0.8f + rnd.nextFloat() * 0.4f);
                }
            }
        }

        void plant() {
            if (!replant || sapling == null) return;
            for (Block b : spots) {
                if (b.isEmpty() && Tag.DIRT.isTagged(b.getRelative(BlockFace.DOWN).getType())) {
                    b.setType(sapling, false);
                    Location sl = b.getLocation().add(0.5, 0.4, 0.5);
                    world.spawnParticle(Particle.HAPPY_VILLAGER, sl, 6, 0.25, 0.2, 0.25, 0);
                    fxSound(world, sl, Sound.ITEM_BONE_MEAL_USE, 0.8f, 1.2f);
                    fxPart(world, Particle.HAPPY_VILLAGER, sl, 10, 0.3, 0.3, 0.3, 0);
                }
            }
        }

        void finishAll() {
            for (Group g : groups.values()) finishGroup(g);
            if (apples > 0) {
                Location at = base.clone().add(0, 1.0, 0);
                fxSound(world, at, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.5f);
                if (fxEnabled && fxParts) appleFx(world, at, 12 + apples * 2);
            }
            plant();
        }
    }

    private void startAnimation(Player p, ItemStack tool, Material logType, Tree tree,
                                List<Block> stem, int groundY, int cutY, boolean survival) {
        World w = stem.get(0).getWorld();
        final boolean cutHigh = cutY > groundY;
        Anim anim = new Anim();
        anim.world = w;
        if (!cutHigh) anim.spots.addAll(stem); // si ripianta solo se l'albero e' rotto alla base
        anim.sapling = saplingFor(logType);
        anim.gy = groundY;

        // centro del tronco nel punto di rottura (media se e' 2x2)
        double cx = 0, cz = 0;
        int bx0 = Integer.MAX_VALUE, bx1 = Integer.MIN_VALUE, bz0 = Integer.MAX_VALUE, bz1 = Integer.MIN_VALUE;
        for (Block b : stem) {
            cx += b.getX() + 0.5;
            cz += b.getZ() + 0.5;
            bx0 = Math.min(bx0, b.getX());
            bx1 = Math.max(bx1, b.getX());
            bz0 = Math.min(bz0, b.getZ());
            bz1 = Math.max(bz1, b.getZ());
        }
        cx /= stem.size();
        cz /= stem.size();

        // direzione di caduta: dalla parte opposta al giocatore
        double dx = cx - p.getLocation().getX();
        double dz = cz - p.getLocation().getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.01) {
            Vector look = p.getLocation().getDirection();
            dx = look.getX();
            dz = look.getZ();
            len = Math.sqrt(dx * dx + dz * dz);
            if (len < 0.01) {
                dx = 1;
                dz = 0;
                len = 1;
            }
        }
        anim.fx = (float) (dx / len);
        anim.fz = (float) (dz / len);

        if (!cutHigh) {
            // rotto alla base: il perno e' il centro del tronco a terra
            anim.px = cx;
            anim.py = groundY + 0.5;
            anim.pz = cz;
            anim.base = new Location(w, cx, groundY, cz);
            anim.hinge = anim.base;
            anim.drop = 0;
        } else {
            // rotto in alto: il pezzo si piega attorno al bordo del ceppo dal lato di caduta,
            // poi, sdraiato, cade a terra davanti al ceppo (che resta in piedi)
            double halfX = (bx1 - bx0 + 1) / 2.0;
            double halfZ = (bz1 - bz0 + 1) / 2.0;
            double ext = halfX * Math.abs(anim.fx) + halfZ * Math.abs(anim.fz);
            anim.px = cx + anim.fx * ext;
            anim.py = cutY;
            anim.pz = cz + anim.fz * ext;
            anim.drop = cutY - groundY;
            anim.base = new Location(w, anim.px + anim.fx * 0.5, groundY, anim.pz + anim.fz * 0.5);
            anim.hinge = new Location(w, cx, cutY, cz);
        }

        List<Block> all = new ArrayList<>(tree.logs);
        all.addAll(tree.leaves);

        final boolean silkTool = tool.getType() == Material.SHEARS
                || tool.getEnchantmentLevel(Enchantment.SILK_TOUCH) > 0;
        final int fortuneLvl = tool.getEnchantmentLevel(Enchantment.FORTUNE);
        final Location canopy = canopyOf(tree, w);
        anim.cutter = p;
        anim.dmgScale = Math.min(2.0, 0.5 + tree.logs.size() / 40.0);
        if (canopy != null) {
            anim.canopyRel = new Vector3f((float) (canopy.getX() - anim.px),
                    (float) (canopy.getY() - anim.py), (float) (canopy.getZ() - anim.pz));
        }
        final BlockData leafSampleData = tree.leaves.isEmpty() ? null : tree.leaves.iterator().next().getBlockData();
        int appleLeafCount = 0;
        int applesGiven = 0;
        Group appleGroup = null;
        Material leafType = null;

        for (Block b : all) {
            final BlockData data = b.getBlockData();
            final int dy = Math.max(0, b.getY() - cutY);
            Collection<ItemStack> drops = survival ? b.getDrops(tool, p) : Collections.emptyList();
            boolean appleLeafHere = false;
            if (survival && Tag.LEAVES.isTagged(data.getMaterial())) {
                List<ItemStack> list = new ArrayList<>();
                if (silkTool) {
                    // Tocco di seta / cesoie: cade la foglia stessa
                    list.add(new ItemStack(data.getMaterial()));
                } else {
                    appleLeafHere = appleAllTrees || appleLeaves.contains(data.getMaterial());
                    leafType = data.getMaterial();
                    for (ItemStack it : drops) {
                        if (appleLeafHere && it.getType() == Material.APPLE) continue; // uso la mia probabilita'
                        list.add(it);
                    }
                    if (appleLeafHere) {
                        double chance = Math.min(1.0, appleChance * (1 + fortuneLvl * fortuneAppleBonus));
                        if (rnd.nextDouble() < chance) {
                            list.add(new ItemStack(Material.APPLE));
                            applesGiven++;
                        }
                    }
                }
                drops = list;
            }
            Location loc = b.getLocation();
            b.setType(Material.AIR, false);

            Group g = anim.group(dy);
            g.drops.addAll(drops);
            if (appleLeafHere) {
                appleLeafCount++;
                appleGroup = g;
            }
            g.sample = data;
            boolean leaf = Tag.LEAVES.isTagged(data.getMaterial());
            if (leaf) g.leafData = data;
            g.dy = dy;

            BlockDisplay d = w.spawn(loc, BlockDisplay.class, x -> {
                x.setBlock(data);
                x.setPersistent(false);
                x.setInterpolationDuration(0);
            });
            g.displays.add(d);
            if (leaf) anim.leafDisplays.add(d);
        }

        // i rampicanti attaccati all'albero si tolgono insieme a lui
        removeVines(p, tree, survival && silkTool && vinesDropWithSilk, w);

        // minimo di mele garantite per albero (se ha foglie che le possono dare)
        if (survival && !silkTool && appleGroup != null && applesGiven < appleMinPerTree) {
            for (int i = applesGiven; i < appleMinPerTree; i++) {
                appleGroup.drops.add(new ItemStack(Material.APPLE));
                applesGiven++;
            }
        }
        anim.apples = applesGiven;
        // le mele 3D appese alle foglie si staccano e cadono come oggetti
        final int fruitApples = detachFruits(w, tree.leaves, survival);
        final int height = anim.groups.isEmpty() ? 0 : anim.groups.lastKey();
        if (debug) {
            getLogger().info("[albero] tronco=" + logType + " foglia=" + leafType + " foglie=" + tree.leaves.size()
                    + " foglie-da-mele=" + appleLeafCount + " mele=" + applesGiven + " survival=" + survival
                    + " attrezzo=" + tool.getType() + " seta/cesoie=" + silkTool + " mele-appese=" + fruitApples);
        }

        active.add(anim);

        // scricchiolio prima della caduta
        for (int i = 0; i < creakTicks; i += 4) {
            final float pitch = 0.6f + (i / (float) Math.max(1, creakTicks)) * 0.5f;
            getServer().getScheduler().runTaskLater(this,
                    () -> w.playSound(anim.hinge, Sound.BLOCK_WOOD_HIT, 0.9f, pitch), i);
        }

        // l'albero ondeggia sempre di piu' prima di cadere
        for (int i = 0; i < creakTicks; i += 2) {
            final float prog = i / (float) Math.max(1, creakTicks);
            final float angle = (0.02f + 0.05f * prog) * (((i / 2) % 2 == 0) ? 1f : 0.2f);
            getServer().getScheduler().runTaskLater(this, () -> pose(anim, angle, 2), i);
        }

        // effetti: polvere, foglie che tremano e SNAP finale del tronco
        if (fxEnabled && creakTicks > 0) {
            final BlockData trunk = logType.createBlockData();
            for (int i = 0; i < creakTicks; i += 3) {
                final float prog = i / (float) Math.max(1, creakTicks);
                getServer().getScheduler().runTaskLater(this, () -> {
                    fxSound(w, anim.hinge, Sound.ENTITY_ZOMBIE_ATTACK_WOODEN_DOOR, 0.35f + prog * 0.3f, 0.5f + prog * 0.4f);
                    fxPart(w, Particle.BLOCK, anim.hinge.clone().add(0, 0.5, 0), 4, 0.35, 0.3, 0.35, 0.05, trunk);
                    if (canopy != null && leafSampleData != null) {
                        fxPart(w, Particle.BLOCK, canopy, (int) Math.round((20 + prog * 30) * leafParticleMult), 1.9, 1.2, 1.9, 0.02, leafSampleData);
                        fxPart(w, Particle.FALLING_DUST, canopy, (int) Math.round((8 + prog * 14) * leafParticleMult), 1.9, 1.2, 1.9, 0.0, leafSampleData);
                        fxSound(w, canopy, Sound.BLOCK_AZALEA_LEAVES_BREAK, 0.5f, 0.7f + prog * 0.4f);
                    }
                }, i);
            }
            // SNAP: il tronco cede e inizia a cadere
            getServer().getScheduler().runTaskLater(this, () -> {
                fxSound(w, anim.hinge, Sound.ENTITY_ZOMBIE_BREAK_WOODEN_DOOR, 0.8f, 0.5f);
                fxSound(w, anim.hinge, Sound.BLOCK_WOOD_BREAK, 1.2f, 0.4f);
                fxSound(w, anim.hinge, Sound.ENTITY_GENERIC_EXPLODE, 0.25f, 1.9f);        // crack secco
                fxSound(w, anim.hinge, Sound.BLOCK_CHERRY_WOOD_BREAK, 1.0f, 0.5f);         // legno che cede
                fxPart(w, Particle.BLOCK, anim.hinge.clone().add(0, 0.6, 0), 30, 0.4, 0.5, 0.4, 0.15, trunk);
            }, creakTicks);
        }

        // caduta: ruota attorno al perno, accelerando, fino a stendersi.
        // Se l'albero e' rotto in alto, una volta sdraiato il pezzo cade a terra davanti al ceppo.
        final int STEP = 2; // ogni quanti tick aggiorno la posa (interpolazione fluida)
        final float HALF_PI = (float) (Math.PI / 2);
        final double GRAVITY = 0.05; // blocchi/tick^2 della caduta verticale
        new BukkitRunnable() {
            int t = 0;
            int landAt = -1;
            int laidAt = -1;
            float theta = 0f;

            @Override
            public void run() {
                if (t % STEP == 0 && landAt < 0) {
                    if (laidAt < 0) {
                        float target = (float) (0.5 * fallSpeed * (t + STEP) * (t + STEP));
                        if (target >= HALF_PI) {
                            target = HALF_PI;
                            laidAt = t + STEP;
                            if (anim.drop <= 0) landAt = t + STEP;
                        }
                        theta = target;
                        pose(anim, theta, STEP, 0f);
                    } else {
                        int n = (t + STEP) - laidAt;
                        anim.curDrop = Math.min(anim.drop, 0.5 * GRAVITY * n * n);
                        pose(anim, HALF_PI, STEP, (float) anim.curDrop);
                        if (anim.curDrop >= anim.drop - 1e-6) landAt = t + STEP;
                    }

                    fallFx(anim, theta, height, t);
                    fallDamage(anim, theta, height);
                    breakColliding(anim, theta, (float) anim.curDrop);

                    // foglie che cadono dalla chioma
                    if (t % 4 == 0 && !anim.leafDisplays.isEmpty()) {
                        Quaternionf q = new Quaternionf(new AxisAngle4f(theta, anim.fz, 0f, -anim.fx));
                        int leafBursts = Math.max(1, (int) Math.round(6 * leafParticleMult));
                        for (int i = 0; i < leafBursts; i++) {
                            BlockDisplay ld = anim.leafDisplays.get(rnd.nextInt(anim.leafDisplays.size()));
                            if (!ld.isValid()) continue;
                            Location l = ld.getLocation();
                            Vector3f v = new Vector3f(
                                    (float) (l.getX() + 0.5 - anim.px),
                                    (float) (l.getY() + 0.5 - anim.py),
                                    (float) (l.getZ() + 0.5 - anim.pz));
                            q.transform(v);
                            BlockData leafData = ld.getBlock();
                            Location pl = new Location(w, anim.px + v.x, anim.py + v.y - anim.curDrop, anim.pz + v.z);
                            w.spawnParticle(Particle.BLOCK, pl, 6, 0.4, 0.4, 0.4, 0.02, leafData);
                            // foglioline che svolazzano e scendono piano
                            w.spawnParticle(Particle.FALLING_DUST, pl, 3, 0.45, 0.3, 0.45, 0.0, leafData);
                        }
                    }
                }

                if (landAt >= 0 && t >= landAt) {
                    w.playSound(anim.base, Sound.BLOCK_WOOD_FALL, 1.2f, 0.6f);
                    w.playSound(anim.base, Sound.BLOCK_GRASS_BREAK, 1.0f, 0.6f);
                    fallDamage(anim, HALF_PI, height);
                    impactFx(anim, height);
                    anim.finishAll();
                    active.remove(anim);
                    cancel();
                    return;
                }
                t++;
            }
        }.runTaskTimer(this, 1L + creakTicks, 1L);
    }

    /**
     * Ruota tutto l'albero di "theta" radianti attorno al perno alla base, verso la direzione di caduta.
     * Per un blocco con angolo in (x,y,z) relativo al perno, la traslazione che serve e' (R - I) * d.
     */
    private void pose(Anim anim, float theta, int duration) {
        pose(anim, theta, duration, 0f);
    }

    /** Come sopra, con in piu' una discesa verticale di dropAmt blocchi (pezzo rotto in alto che cade a terra). */
    private void pose(Anim anim, float theta, int duration, float dropAmt) {
        Quaternionf q = new Quaternionf(new AxisAngle4f(theta, anim.fz, 0f, -anim.fx));
        for (Group g : anim.groups.values()) {
            if (g.done) continue;
            for (BlockDisplay d : g.displays) {
                if (!d.isValid()) continue;
                Location l = d.getLocation();
                Vector3f dv = new Vector3f(
                        (float) (l.getX() - anim.px),
                        (float) (l.getY() - anim.py),
                        (float) (l.getZ() - anim.pz));
                Vector3f rv = q.transform(new Vector3f(dv));
                rv.sub(dv);
                rv.y -= dropAmt;
                d.setInterpolationDelay(0);
                d.setInterpolationDuration(duration);
                d.setTransformation(new Transformation(
                        rv,
                        new AxisAngle4f(theta, anim.fz, 0f, -anim.fx),
                        new Vector3f(1f, 1f, 1f),
                        new AxisAngle4f()));
            }
        }
    }

    /**
     * Collisioni: ogni blocco dell'albero che mentre cade tocca un blocco solido del mondo
     * (terreno, muri, altri alberi...) si rompe all'istante, con schegge e suono.
     * Si controlla il nucleo del cubo (7/10 della sua dimensione) cosi' il tronco che poggia
     * semplicemente a terra non si rompe, ma quello che affonda nel suolo si'.
     */
    private void breakColliding(Anim anim, float theta, float dropAmt) {
        if (!collisionBreak || theta < 0.05f) return;
        World w = anim.world;
        Quaternionf q = new Quaternionf(new AxisAngle4f(theta, anim.fz, 0f, -anim.fx));
        Vector3f ax = q.transform(new Vector3f(0.35f, 0f, 0f));
        Vector3f ay = q.transform(new Vector3f(0f, 0.35f, 0f));
        Vector3f az = q.transform(new Vector3f(0f, 0f, 0.35f));
        int sounds = 0, broken = 0;
        for (Group g : anim.groups.values()) {
            if (g.done) continue;
            List<BlockDisplay> gone = null;
            for (BlockDisplay d : g.displays) {
                if (!d.isValid()) continue;
                Location l = d.getLocation();
                Vector3f c = new Vector3f(
                        (float) (l.getX() + 0.5 - anim.px),
                        (float) (l.getY() + 0.5 - anim.py),
                        (float) (l.getZ() + 0.5 - anim.pz));
                q.transform(c);
                double cx = anim.px + c.x, cy = anim.py + c.y - dropAmt, cz = anim.pz + c.z;
                // attorno al perno (ceppo / base) i blocchi non si rompono: li' c'e' la cerniera
                if (Math.abs(c.x) < 1.6 && Math.abs(c.z) < 1.6) continue;

                Block hb = solidBlockAt(w, cx, cy, cz);
                for (int k = 0; hb == null && k < 8; k++) {
                    double sx = (k & 1) == 0 ? -1 : 1, sy = (k & 2) == 0 ? -1 : 1, sz = (k & 4) == 0 ? -1 : 1;
                    hb = solidBlockAt(w, cx + sx * ax.x + sy * ay.x + sz * az.x,
                            cy + sx * ax.y + sy * ay.y + sz * az.y,
                            cz + sx * ax.z + sy * ay.z + sz * az.z);
                }
                if (hb == null) continue;

                BlockData data = d.getBlock();
                Location at = new Location(w, cx, cy, cz);
                w.spawnParticle(Particle.BLOCK, at, 10, 0.25, 0.25, 0.25, 0.06, data);
                broken++;
                if (sounds < 8) {
                    sounds++;
                    breakSound(w, at, data, hb.getBlockData());
                }
                d.remove();
                if (gone == null) gone = new ArrayList<>();
                gone.add(d);
            }
            if (gone != null) g.displays.removeAll(gone);
        }
        if (broken >= 3) {
            Location mid = new Location(w, anim.px + anim.fx * 3, anim.gy + 1, anim.pz + anim.fz * 3);
            float v = (float) fxVolume;
            // piu' blocchi cedono insieme, piu' lo schianto e' pieno: botto, legno pesante, detriti
            w.playSound(mid, Sound.ENTITY_GENERIC_EXPLODE, 0.3f * v, 1.3f);
            w.playSound(mid, Sound.BLOCK_WOOD_FALL, 1.1f * v, 0.5f);
            w.playSound(mid, Sound.BLOCK_GRAVEL_BREAK, 0.8f * v, 0.6f);
            if (broken >= 8) w.playSound(mid, Sound.ENTITY_IRON_GOLEM_DAMAGE, 0.6f * v, 0.5f);
            // pioggia di schegge e foglie che si assestano subito dopo
            getServer().getScheduler().runTaskLater(this, () -> {
                w.playSound(mid, Sound.BLOCK_BAMBOO_WOOD_BREAK, 0.7f * v, 0.9f + rnd.nextFloat() * 0.3f);
                w.playSound(mid, Sound.BLOCK_GRAVEL_STEP, 0.7f * v, 0.7f);
            }, 3L);
        }
    }

    private Block solidBlockAt(World w, double x, double y, double z) {
        int bx = (int) Math.floor(x), by = (int) Math.floor(y), bz = (int) Math.floor(z);
        if (by < w.getMinHeight() || by >= w.getMaxHeight()) return null;
        if (!w.isChunkLoaded(bx >> 4, bz >> 4)) return null;
        Block b = w.getBlockAt(bx, by, bz);
        return b.getType().isSolid() ? b : null;
    }

    /**
     * Schianto di un blocco in volo contro un ostacolo: suono del blocco che si spezza (legno secco,
     * foglie croccanti, pietra sorda) piu' il suono dell'ostacolo colpito (terra, pietra, altro tronco...).
     */
    private void breakSound(World w, Location at, BlockData data, BlockData obstacle) {
        float v = (float) fxVolume;
        Material m = data.getMaterial();
        float r = rnd.nextFloat();
        if (Tag.LOGS.isTagged(m) || Tag.PLANKS.isTagged(m)) {
            w.playSound(at, Sound.BLOCK_WOOD_BREAK, 1.5f * v, 0.55f + r * 0.2f);
            w.playSound(at, Sound.BLOCK_CHERRY_WOOD_BREAK, 1.0f * v, 0.9f + r * 0.3f);
            w.playSound(at, Sound.BLOCK_BAMBOO_WOOD_BREAK, 0.9f * v, 0.7f + r * 0.4f);   // schianto secco
            w.playSound(at, Sound.BLOCK_WOOD_FALL, 0.9f * v, 0.5f + r * 0.2f);          // peso del tronco
        } else if (Tag.LEAVES.isTagged(m)) {
            w.playSound(at, Sound.BLOCK_GRASS_BREAK, 1.2f * v, 0.8f + r * 0.3f);
            w.playSound(at, Sound.BLOCK_AZALEA_LEAVES_BREAK, 1.0f * v, 1.0f + r * 0.3f);
            w.playSound(at, Sound.BLOCK_SWEET_BERRY_BUSH_BREAK, 0.7f * v, 0.9f + r * 0.3f); // foglie che frusciano
        } else {
            w.playSound(at, data.getSoundGroup().getBreakSound(), 1.4f * v, 0.7f + r * 0.35f);
            w.playSound(at, Sound.BLOCK_STONE_BREAK, 0.8f * v, 0.7f);
        }
        if (obstacle != null) {
            // l'ostacolo risponde: tonfo sordo sulla terra, colpo secco sulla pietra, ecc.
            w.playSound(at, obstacle.getSoundGroup().getHitSound(), 1.1f * v, 0.6f + r * 0.2f);
            w.playSound(at, obstacle.getSoundGroup().getBreakSound(), 0.7f * v, 0.6f + r * 0.3f);
        }
    }

    private boolean solidAt(World w, double x, double y, double z) {
        int bx = (int) Math.floor(x), by = (int) Math.floor(y), bz = (int) Math.floor(z);
        if (by < w.getMinHeight() || by >= w.getMaxHeight()) return false;
        if (!w.isChunkLoaded(bx >> 4, bz >> 4)) return false;
        return w.getBlockAt(bx, by, bz).getType().isSolid();
    }

    // ------------------------------------------------------------------ mele 3D sugli alberi

    private static final class Fruit {
        final UUID id, world;
        final UUID[] parts;          // entita' visive (corpo, gambo...)
        final int lx, ly, lz;        // foglia a cui e' appesa
        final double x, y, z;        // centro della mela

        Fruit(UUID id, UUID world, UUID[] parts, int lx, int ly, int lz, double x, double y, double z) {
            this.id = id;
            this.world = world;
            this.parts = parts;
            this.lx = lx;
            this.ly = ly;
            this.lz = lz;
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    private static long pack(int x, int y, int z) {
        return (((long) x & 0x3FFFFFFL) << 38) | (((long) z & 0x3FFFFFFL) << 12) | ((long) y & 0xFFFL);
    }

    private boolean fruitLeaf(Block b) {
        if (!naturalLeaf(b)) return false;
        return appleAllTrees || appleLeaves.contains(b.getType());
    }

    private int cnt(int n) {
        return Math.max(1, (int) Math.round(n * fxScale));
    }

    // --- click sinistro sulla mela (la hitbox e' un'entita' Interaction)

    private boolean isFruitEntity(Entity e) {
        return e instanceof Interaction && e.getPersistentDataContainer().has(fruitKey, PersistentDataType.INTEGER_ARRAY);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFruitAttack(PrePlayerAttackEntityEvent e) {
        Entity t = e.getAttacked();
        if (!isFruitEntity(t)) return;
        e.setCancelled(true);
        hitFruit(e.getPlayer(), t);
    }

    /** Rete di sicurezza: alcune versioni propagano il colpo anche come danno. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFruitDamage(EntityDamageByEntityEvent e) {
        if (!isFruitEntity(e.getEntity())) return;
        e.setCancelled(true);
        if (e.getDamager() instanceof Player p) hitFruit(p, e.getEntity());
    }

    private void hitFruit(Player p, Entity target) {
        if (!target.isValid()) return; // gia' rotta da un altro evento dello stesso click
        Fruit f = fruits.get(target.getUniqueId());
        if (f == null && target instanceof Interaction ia) {
            register(ia);
            f = fruits.get(target.getUniqueId());
        }
        if (f == null) return;
        boolean drop = p.getGameMode() != GameMode.CREATIVE || fruitDropCreative;
        popFruit(f, drop);
    }

    // --- registro delle mele caricate

    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent e) {
        for (Entity en : e.getEntities()) if (en instanceof Interaction ia) register(ia);
        purgeLegacyBranches(e.getEntities());
    }

    @EventHandler
    public void onEntitiesUnload(EntitiesUnloadEvent e) {
        for (Entity en : e.getEntities()) if (en instanceof Interaction) fruits.remove(en.getUniqueId());
    }

    private void loadExistingFruits() {
        for (World w : Bukkit.getWorlds()) {
            for (Interaction ia : w.getEntitiesByClass(Interaction.class)) register(ia);
        }
    }

    private void register(Interaction ia) {
        PersistentDataContainer pdc = ia.getPersistentDataContainer();
        int[] leaf = pdc.get(fruitKey, PersistentDataType.INTEGER_ARRAY);
        if (leaf == null || leaf.length != 3) return;
        String raw = pdc.getOrDefault(fruitPartsKey, PersistentDataType.STRING, "");
        List<UUID> parts = new ArrayList<>();
        for (String sp : raw.split(",")) {
            if (sp.isBlank()) continue;
            try {
                parts.add(UUID.fromString(sp.trim()));
            } catch (IllegalArgumentException ignored) {
            }
        }
        Location l = ia.getLocation();
        fruits.put(ia.getUniqueId(), new Fruit(ia.getUniqueId(), l.getWorld().getUID(), parts.toArray(new UUID[0]),
                leaf[0], leaf[1], leaf[2], l.getX(), l.getY() + ia.getInteractionHeight() / 2.0, l.getZ()));
    }

    private void removeEntity(UUID id) {
        Entity en = Bukkit.getEntity(id);
        if (en != null) en.remove();
    }

    // --- rottura

    /** Rompe la mela: effetti, rimuove le entita' e (se drop) lascia cadere la mela come oggetto. */
    private void popFruit(Fruit f, boolean drop) {
        if (fruits.remove(f.id) == null) return;
        removeEntity(f.id);
        for (UUID u : f.parts) removeEntity(u);
        World w = Bukkit.getWorld(f.world);
        if (w == null) return;
        Location at = new Location(w, f.x, f.y, f.z);
        popFx(w, at);
        if (drop) w.dropItemNaturally(at, new ItemStack(Material.APPLE, fruitDropAmount));
    }

    /** Particelle rosse delle mele: pezzetti di mela + polvere rossa. */
    private void appleFx(World w, Location at, int n) {
        w.spawnParticle(Particle.ITEM, at, n, 0.2, 0.2, 0.2, 0.05, new ItemStack(Material.APPLE));
        w.spawnParticle(Particle.DUST, at, n, 0.2, 0.2, 0.2, 0,
                new Particle.DustOptions(Color.fromRGB(205, 25, 25), 1.0f));
    }

    private void popFx(World w, Location at) {
        if (fruitSounds) {
            float v = (float) fxVolume;
            w.playSound(at, Sound.BLOCK_SWEET_BERRY_BUSH_PICK_BERRIES, 1.0f * v, 0.9f + rnd.nextFloat() * 0.3f);
            w.playSound(at, Sound.ENTITY_GENERIC_EAT, 0.7f * v, 1.4f + rnd.nextFloat() * 0.3f);
            w.playSound(at, Sound.BLOCK_AZALEA_LEAVES_BREAK, 0.6f * v, 1.1f);
        }
        if (fruitParticles) {
            appleFx(w, at, cnt(8));
        }
    }

    /** Albero abbattuto dal plugin: le mele appese alle sue foglie si staccano e cadono. */
    private int detachFruits(World w, Collection<Block> leaves, boolean survival) {
        if (fruits.isEmpty() || leaves.isEmpty()) return 0;
        Set<Long> keys = new HashSet<>();
        for (Block b : leaves) keys.add(pack(b.getX(), b.getY(), b.getZ()));
        boolean drop = survival || fruitDropCreative;
        UUID wid = w.getUID();
        int n = 0;
        for (Fruit f : new ArrayList<>(fruits.values())) {
            if (!f.world.equals(wid)) continue;
            if (!keys.contains(pack(f.lx, f.ly, f.lz))) continue;
            popFruit(f, drop);
            n++;
        }
        return n;
    }

    /** Ogni mezzo secondo: se la foglia non c'e' piu' (decadimento, rotta, esplosione...) la mela cade. */
    private void validateFruits() {
        if (fruits.isEmpty()) return;
        for (Fruit f : new ArrayList<>(fruits.values())) {
            World w = Bukkit.getWorld(f.world);
            Entity ia = Bukkit.getEntity(f.id);
            if (ia == null) {
                // scaricata (le parti restano nel chunk) oppure eliminata a mano (ripulisco le parti)
                fruits.remove(f.id);
                if (w != null && w.isChunkLoaded(((int) Math.floor(f.x)) >> 4, ((int) Math.floor(f.z)) >> 4)) {
                    for (UUID u : f.parts) removeEntity(u);
                }
                continue;
            }
            if (w == null || !ia.isValid()) {
                fruits.remove(f.id);
                for (UUID u : f.parts) removeEntity(u);
                continue;
            }
            if (!w.isChunkLoaded(f.lx >> 4, f.lz >> 4)) continue;
            if (!Tag.LEAVES.isTagged(w.getBlockAt(f.lx, f.ly, f.lz).getType())) popFruit(f, true);
        }
    }

    // --- comparsa delle mele attorno ai giocatori

    private void spawnFruitsCycle() {
        if (!fruitEnabled || fruits.size() >= fruitMaxTotal) return;
        if (++fruitCycleCounter < fruitCycleSeconds) return;
        fruitCycleCounter = 0;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getGameMode() == GameMode.SPECTATOR) continue;
            if (!worlds.isEmpty() && !worlds.contains(p.getWorld().getName())) continue;
            spawnFruitsAround(p, fruitAttempts, fruitSpawnChance);
        }
    }

    private int spawnFruitsAround(Player p, int attempts, double chance) {
        World w = p.getWorld();
        Location pl = p.getLocation();
        int made = 0;
        for (int i = 0; i < attempts; i++) {
            if (fruits.size() >= fruitMaxTotal) break;
            if (rnd.nextDouble() >= chance) continue;
            int x = pl.getBlockX() + rnd.nextInt(fruitRadius * 2 + 1) - fruitRadius;
            int z = pl.getBlockZ() + rnd.nextInt(fruitRadius * 2 + 1) - fruitRadius;
            if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
            int top = w.getHighestBlockYAt(x, z);
            int bottom = Math.max(w.getMinHeight() + 1, top - 14);
            // dall'alto verso il basso: prima foglia naturale con aria sotto (il "fondo" della chioma)
            for (int y = top; y >= bottom; y--) {
                Block b = w.getBlockAt(x, y, z);
                if (!fruitLeaf(b)) continue;
                if (!w.getBlockAt(x, y - 1, z).getType().isAir()) continue;
                if (trySpawnFruit(b)) made++;
                break;
            }
        }
        return made;
    }

    private boolean trySpawnFruit(Block leaf) {
        World w = leaf.getWorld();
        float s = 0.24f * (float) fruitSize;
        double cx = leaf.getX() + 0.5 + (rnd.nextDouble() - 0.5) * 0.4;
        double cz = leaf.getZ() + 0.5 + (rnd.nextDouble() - 0.5) * 0.4;
        double cy = leaf.getY() - 0.08 - s / 2.0; // appesa sotto la foglia, il gambo tocca il blocco

        UUID wid = w.getUID();
        int near = 0;
        for (Fruit f : fruits.values()) {
            if (!f.world.equals(wid)) continue;
            double dx = f.x - cx, dy = f.y - cy, dz = f.z - cz;
            double d2 = dx * dx + dy * dy + dz * dz;
            if (d2 < 0.8) return false; // troppo vicina a un'altra mela
            if (d2 < 25.0) near++;
        }
        if (near >= fruitMaxPerTree) return false;

        spawnFruit(w, leaf, cx, cy, cz, s);
        return true;
    }

    private void spawnFruit(World w, Block leaf, double cx, double cy, double cz, float s) {
        Location at = new Location(w, cx, cy, cz);
        List<UUID> parts = new ArrayList<>();
        float yaw = rnd.nextFloat() * (float) (Math.PI * 2);

        if (!fruitHeadTexture.isEmpty()) {
            parts.add(headPart(w, at));
        } else {
            // mela 3D: corpo tondo (cubi ruotati), spalle piu' larghe in alto, base rastremata,
            // fossetta scura, riflesso, gambo storto e fogliolina
            Quaternionf rotA = new Quaternionf().rotateY(yaw);
            Quaternionf rotB = new Quaternionf().rotateY(yaw + (float) (Math.PI / 4));
            Quaternionf rotC = new Quaternionf().rotateY(yaw + (float) (Math.PI / 8));
            Quaternionf rotD = new Quaternionf().rotateY(yaw + (float) (3 * Math.PI / 8));
            Material red = Material.RED_CONCRETE;
            Material dark = Material.NETHER_WART_BLOCK;
            // corpo centrale (ottagono)
            parts.add(blockPart(w, at, red, rotA, s * 0.86f, s * 0.80f, s * 0.86f, 0f, 0f, 0f));
            parts.add(blockPart(w, at, red, rotB, s * 0.86f, s * 0.80f, s * 0.86f, 0f, 0f, 0f));
            // spalle: piu' larghe in alto
            parts.add(blockPart(w, at, red, rotC, s * 0.96f, s * 0.38f, s * 0.96f, 0f, s * 0.20f, 0f));
            parts.add(blockPart(w, at, red, rotD, s * 0.96f, s * 0.38f, s * 0.96f, 0f, s * 0.20f, 0f));
            // base rastremata e piu' scura
            parts.add(blockPart(w, at, dark, rotC, s * 0.62f, s * 0.26f, s * 0.62f, 0f, -s * 0.42f, 0f));
            // fossetta scura attorno al gambo
            parts.add(blockPart(w, at, dark, rotA, s * 0.26f, s * 0.06f, s * 0.26f, 0f, s * 0.40f, 0f));
            // riflesso lucido
            parts.add(blockPart(w, at, Material.PINK_CONCRETE, rotA, s * 0.05f, s * 0.20f, s * 0.14f,
                    s * 0.48f * (float) Math.cos(yaw), s * 0.16f, s * 0.48f * (float) Math.sin(-yaw)));
            // gambo leggermente storto
            Quaternionf stemRot = new Quaternionf().rotateY(yaw).rotateZ(0.28f);
            parts.add(blockPart(w, at, Material.DARK_OAK_WOOD, stemRot, s * 0.09f, s * 0.26f, s * 0.09f,
                    0f, s / 2f + s * 0.12f, 0f));
            // fogliolina verde
            Quaternionf leafRot = new Quaternionf().rotateY(yaw).rotateZ(-0.35f);
            parts.add(blockPart(w, at, Material.LIME_CONCRETE, leafRot, s * 0.30f, s * 0.03f, s * 0.16f,
                    s * 0.20f * (float) Math.cos(yaw), s / 2f + s * 0.22f, -s * 0.20f * (float) Math.sin(yaw)));
        }

        float ih = Math.max(0.3f, s + 0.12f);
        Location iloc = new Location(w, cx, cy - ih / 2.0, cz);
        StringBuilder joined = new StringBuilder();
        for (UUID u : parts) {
            if (joined.length() > 0) joined.append(',');
            joined.append(u);
        }
        final String partsStr = joined.toString();
        final int[] leafPos = {leaf.getX(), leaf.getY(), leaf.getZ()};
        Interaction ia = w.spawn(iloc, Interaction.class, i -> {
            i.setInteractionWidth(ih);
            i.setInteractionHeight(ih);
            i.setPersistent(true);
            PersistentDataContainer pdc = i.getPersistentDataContainer();
            pdc.set(fruitKey, PersistentDataType.INTEGER_ARRAY, leafPos);
            pdc.set(fruitPartsKey, PersistentDataType.STRING, partsStr);
        });
        fruits.put(ia.getUniqueId(), new Fruit(ia.getUniqueId(), wid(w), parts.toArray(new UUID[0]),
                leaf.getX(), leaf.getY(), leaf.getZ(), cx, cy, cz));
    }

    private static UUID wid(World w) {
        return w.getUID();
    }

    /** Un cubo (scalato/ruotato) centrato sul punto "at" + offset. */
    private UUID blockPart(World w, Location at, Material m, Quaternionf rot,
                           float sx, float sy, float sz, float ox, float oy, float oz) {
        Vector3f half = new Vector3f(sx / 2f, sy / 2f, sz / 2f).rotate(rot);
        Vector3f tr = new Vector3f(ox - half.x, oy - half.y, oz - half.z);
        BlockDisplay d = w.spawn(at, BlockDisplay.class, e -> {
            e.setBlock(m.createBlockData());
            e.setTransformation(new Transformation(tr, new Quaternionf(rot), new Vector3f(sx, sy, sz), new Quaternionf()));
            e.setBrightness(new Display.Brightness(13, 15)); // resta ben visibile sotto le foglie
            e.setViewRange(0.35f);
            e.setPersistent(true);
        });
        return d.getUniqueId();
    }

    /** Variante con testa personalizzata (fruit.head-texture = valore base64 della skin). */
    private UUID headPart(World w, Location at) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        if (head.getItemMeta() instanceof SkullMeta sm) {
            PlayerProfile prof = Bukkit.createProfile(UUID.nameUUIDFromBytes(fruitHeadTexture.getBytes()), null);
            prof.setProperty(new ProfileProperty("textures", fruitHeadTexture));
            sm.setPlayerProfile(prof);
            head.setItemMeta(sm);
        }
        final float sc = (float) (fruitHeadScale * fruitSize);
        ItemDisplay d = w.spawn(at, ItemDisplay.class, e -> {
            e.setItemStack(head);
            e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.HEAD);
            e.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(sc, sc, sc), new Quaternionf()));
            e.setBrightness(new Display.Brightness(13, 15));
            e.setViewRange(0.35f);
            e.setPersistent(true);
        });
        return d.getUniqueId();
    }

    // ------------------------------------------------------------------ utility

    private Material saplingFor(Material log) {
        String n = log.name();
        if (n.equals("MANGROVE_LOG")) return Material.matchMaterial("MANGROVE_PROPAGULE");
        if (n.endsWith("_LOG")) return Material.matchMaterial(n.substring(0, n.length() - 4) + "_SAPLING");
        return null;
    }

    private List<ItemStack> merge(List<ItemStack> in) {
        List<ItemStack> out = new ArrayList<>();
        for (ItemStack it : in) {
            if (it == null || it.getType().isAir()) continue;
            int left = it.getAmount();
            for (ItemStack o : out) {
                if (left <= 0) break;
                if (o.isSimilar(it)) {
                    int add = Math.min(o.getMaxStackSize() - o.getAmount(), left);
                    o.setAmount(o.getAmount() + add);
                    left -= add;
                }
            }
            if (left > 0) {
                ItemStack c = it.clone();
                c.setAmount(left);
                out.add(c);
            }
        }
        return out;
    }
}
