# TreeSink

Plugin per Paper 1.21.x: spezza l'albero dove lo colpisci, la parte sopra cade a terra con animazione, effetti e suoni, sotto resta il ceppo.

## Requisiti
- Paper 1.21.4 o superiore, Java 21

## Installazione
```
mvn package
```
Metti `target/TreeSink.jar` nella cartella `plugins/` del server.

## Comandi
- `/treesink toggle` attiva/disattiva il plugin
- `/treesink reload` ricarica la config
- `/treesink fruits` genera mele di prova (permesso `treesink.reload`)

## Autore
[mikaelzer0](https://github.com/mikaelzer0)
