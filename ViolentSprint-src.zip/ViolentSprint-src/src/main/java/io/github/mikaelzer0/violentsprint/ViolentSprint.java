package io.github.mikaelzer0.violentsprint;

import io.github.mikaelzer0.violentsprint.Commands;
import io.github.mikaelzer0.violentsprint.Compat;
import io.github.mikaelzer0.violentsprint.Menus;
import io.github.mikaelzer0.violentsprint.Settings;
import io.github.mikaelzer0.violentsprint.Zone;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityEvent;
import org.bukkit.event.player.PlayerCommandSendEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class ViolentSprint
extends JavaPlugin
implements Listener {
    static final String UNKNOWN_COMMAND = "Unknown command. Type \"/help\" for help.";
    private static final double KNOCKBACK_BLOCK_UNIT = 0.35;
    private static final long KNOCKBACK_FLIGHT_TRACK_TICKS = 40L;
    private static final double KNOCKBACK_CONFIRM_RATIO = 0.4;
    private static final double FRAGMENT_HIT_RADIUS = 0.6;
    private static final double FALL_MIN_DAMAGE = 4.0;
    private static final double FALL_BIG_DAMAGE = 9.0;
    private static final double ELYTRA_MIN_DAMAGE = 3.0;
    private static final double ELYTRA_DAMAGE_PER_LAYER = 4.0;
    private static final int ELYTRA_MAX_DEPTH = 3;
    private static final double SPEAR_MIN_SPEED = 0.4;
    private static final double SPEAR_BASE_KNOCKBACK = 0.7;
    private static final double SPEAR_KNOCKBACK_PER_SPEED = 1.5;
    private static final double SPEAR_MAX_KNOCKBACK = 2.5;
    private static final double MAX_SANE_DELTA = 6.0;
    private static final Pattern ZONE_NAME = Pattern.compile("[a-z0-9_-]{1,20}");
    private static final Set<Material> UNBREAKABLE_EXTRA = Compat.unbreakableMaterials();
    boolean breakEverywhere = false;
    final Settings settings = new Settings();
    final Set<Material> globalProtected = EnumSet.noneOf(Material.class);
    final Map<String, Zone> zones = new TreeMap<String, Zone>();
    final Map<UUID, String> pendingZoneByPlayer = new HashMap<UUID, String>();
    Menus menus;
    private final Set<BlockState> pendingRegen = Collections.newSetFromMap(new IdentityHashMap());
    private final List<Fragment> fragments = new ArrayList<Fragment>();
    private final Set<UUID> trackedFlights = new HashSet<UUID>();
    private final Map<UUID, Motion> motion = new HashMap<UUID, Motion>();
    private final Set<String> ownCommandNames = new HashSet<String>();
    private boolean paperKnockbackHook = false;
    private File zonesFile;
    private FileConfiguration zonesConfig;

    static boolean isAdmin(CommandSender sender) {
        return sender.isOp();
    }

    public void onEnable() {
        this.saveDefaultConfig();
        this.settings.load(this.getConfig());
        this.loadZonesConfig();
        this.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this);
        this.registerPaperKnockbackHook();
        this.startMotionTracker();
        this.startFragmentTicker();
        this.menus = new Menus(this);
        this.getServer().getPluginManager().registerEvents((Listener)this.menus, (Plugin)this);
        Commands commands = new Commands(this);
        for (String name : new String[]{"vs", "row", "tcreate", "t1", "t2", "tlist", "tremove"}) {
            PluginCommand pc = this.getCommand(name);
            if (pc == null) continue;
            pc.setExecutor((CommandExecutor)commands);
            pc.setTabCompleter((TabCompleter)commands);
            this.registerCommandNames(pc);
        }
        this.getLogger().info("ViolentSprint " + this.getDescription().getVersion() + " abilitato su " + Bukkit.getBukkitVersion() + " | knockback: " + (this.paperKnockbackHook ? "EntityKnockbackEvent (Paper)" : "fallback danno+velocit\u00e0") + " | frammenti 3D: " + (Compat.DISPLAY_SUPPORTED && this.settings.fragmentsEnabled ? "si" : "no"));
    }

    public void onDisable() {
        for (BlockState state : new ArrayList<BlockState>(this.pendingRegen)) {
            this.restore(state, false);
        }
        this.pendingRegen.clear();
        for (Fragment f : this.fragments) {
            if (!f.display.isValid()) continue;
            f.display.remove();
        }
        this.fragments.clear();
    }

    private void registerCommandNames(PluginCommand pc) {
        String prefix = this.getName().toLowerCase(Locale.ROOT) + ":";
        ArrayList<String> names = new ArrayList<String>(pc.getAliases());
        names.add(pc.getName());
        for (String n : names) {
            n = n.toLowerCase(Locale.ROOT);
            this.ownCommandNames.add(prefix + n);
            PluginCommand registered = this.getServer().getPluginCommand(n);
            if (registered == null || registered.getPlugin() != this) continue;
            this.ownCommandNames.add(n);
        }
    }

    @EventHandler
    public void onCommandSend(PlayerCommandSendEvent event) {
        if (ViolentSprint.isAdmin((CommandSender)event.getPlayer())) {
            return;
        }
        event.getCommands().removeAll(this.ownCommandNames);
    }

    void reloadAll() {
        this.reloadConfig();
        this.settings.load(this.getConfig());
        this.loadZonesConfig();
    }

    void audit(CommandSender who, String action) {
        if (this.settings.auditLog) {
            this.getLogger().info("[AUDIT] " + who.getName() + ": " + action);
        }
    }

    void setBreakEverywhere(CommandSender who, boolean on) {
        this.breakEverywhere = on;
        this.saveZonesConfig();
        this.audit(who, "modalit\u00e0 universale " + (on ? "ATTIVATA" : "DISATTIVATA"));
    }

    List<String> statusLines() {
        int active = 0;
        for (Zone z : this.zones.values()) {
            if (!z.enabled || !z.isComplete()) continue;
            ++active;
        }
        ArrayList<String> l = new ArrayList<String>();
        l.add("\u00a77Versione: \u00a7f" + this.getDescription().getVersion() + " \u00a77su \u00a7f" + Bukkit.getBukkitVersion());
        l.add("\u00a77Rilevamento knockback: \u00a7f" + (this.paperKnockbackHook ? "Paper (evento dedicato)" : "compatibile (danno + velocit\u00e0)"));
        l.add("\u00a77Frammenti 3D: \u00a7f" + (Compat.DISPLAY_SUPPORTED && this.settings.fragmentsEnabled ? "attivi" : "disattivati"));
        l.add("\u00a77Modalit\u00e0 universale: " + (this.breakEverywhere ? "\u00a7aATTIVA" : "\u00a77spenta"));
        l.add("\u00a77Zone: \u00a7f" + this.zones.size() + " \u00a77(attive e complete: \u00a7f" + active + "\u00a77)");
        l.add("\u00a77Blocchi in rigenerazione: \u00a7f" + this.pendingRegen.size() + "\u00a77/\u00a7f" + this.settings.maxPendingBlocks);
        l.add("\u00a77Frammenti in volo: \u00a7f" + this.fragments.size() + "\u00a77/\u00a7f" + this.settings.maxActiveFragments);
        l.add("\u00a77Gestione (menu e comandi): \u00a7fsolo OP");
        return l;
    }

    private boolean worldEnabled(World world) {
        return world != null && !this.settings.disabledWorlds.contains(world.getName().toLowerCase(Locale.ROOT));
    }

    private boolean hasActiveAreaIn(World world) {
        if (!this.worldEnabled(world)) {
            return false;
        }
        if (this.breakEverywhere) {
            return true;
        }
        String name = world.getName();
        for (Zone z : this.zones.values()) {
            if (!z.enabled || !z.isComplete() || !z.world.equals(name)) continue;
            return true;
        }
        return false;
    }

    private void registerPaperKnockbackHook() {
        try {
            Class<?> eventClass = Class.forName("io.papermc.paper.event.entity.EntityKnockbackEvent");
            Method kbMethod = null;
            for (String name : new String[]{"getKnockback", "getFinalKnockback"}) {
                try {
                    kbMethod = eventClass.getMethod(name, new Class[0]);
                    break;
                }
                catch (NoSuchMethodException noSuchMethodException) {
                }
            }
            if (kbMethod == null) {
                return;
            }
            Method getKb = kbMethod;
            this.getServer().getPluginManager().registerEvent((Class<? extends org.bukkit.event.Event>)eventClass, (Listener)this, EventPriority.NORMAL, (listener, event) -> {
                if (!eventClass.isInstance(event) || !(event instanceof EntityEvent)) {
                    return;
                }
                Entity victim = ((EntityEvent)event).getEntity();
                if (!this.hasActiveAreaIn(victim.getWorld())) {
                    return;
                }
                try {
                    Vector kb = (Vector)getKb.invoke((Object)event, new Object[0]);
                    if (kb != null) {
                        this.handleKnockback(victim, kb.clone());
                    }
                }
                catch (ReflectiveOperationException ex) {
                    this.getLogger().warning("Errore leggendo il knockback: " + ex.getMessage());
                }
            }, (Plugin)this, true);
            this.paperKnockbackHook = true;
        }
        catch (Throwable ignored) {
            this.paperKnockbackHook = false;
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onAttack(EntityDamageByEntityEvent event) {
        LivingEntity attacker;
        if (!(event.getEntity() instanceof LivingEntity)) {
            return;
        }
        LivingEntity victim = (LivingEntity)event.getEntity();
        if (!this.hasActiveAreaIn(victim.getWorld())) {
            return;
        }
        if (event.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK && event.getDamager() instanceof LivingEntity && Compat.holdsSpear(attacker = (LivingEntity)event.getDamager()) && this.handleSpear(attacker, victim)) {
            return;
        }
        if (!this.paperKnockbackHook) {
            Bukkit.getScheduler().runTask((Plugin)this, () -> {
                if (!victim.isValid()) {
                    return;
                }
                this.handleKnockback((Entity)victim, victim.getVelocity().clone());
            });
        }
    }

    private void handleKnockback(Entity entity, Vector kb) {
        Vector horizontal = new Vector(kb.getX(), 0.0, kb.getZ());
        double force = horizontal.length();
        if (force < this.settings.minKnockbackForce) {
            return;
        }
        Vector direction = horizontal.normalize();
        int blocksToBreak = this.clamp((int)Math.round(force / 0.35), 1, this.settings.maxTunnelLength);
        int broken = this.breakTunnel(entity, entity.getLocation(), direction, blocksToBreak);
        if (entity instanceof LivingEntity) {
            LivingEntity living = (LivingEntity)entity;
            if (broken > 0) {
                this.scheduleGuaranteedKnockback(living, kb);
            }
            this.trackKnockbackFlight(living);
        }
    }

    private void trackKnockbackFlight(final LivingEntity entity) {
        final UUID id = entity.getUniqueId();
        if (!this.trackedFlights.add(id)) {
            return;
        }
        new BukkitRunnable(){
            int ticks = 0;

            private void stop() {
                ViolentSprint.this.trackedFlights.remove(id);
                this.cancel();
            }

            public void run() {
                if (!entity.isValid() || (long)this.ticks >= 40L) {
                    this.stop();
                    return;
                }
                Vector velocity = entity.getVelocity();
                Vector horizontal = new Vector(velocity.getX(), 0.0, velocity.getZ());
                double speed = horizontal.length();
                if (speed < ViolentSprint.this.settings.minKnockbackForce) {
                    this.stop();
                    return;
                }
                Vector dir = horizontal.normalize();
                Location ahead = entity.getLocation().add(dir);
                if (ViolentSprint.this.isObstructed(ahead)) {
                    Vector currentVelocity = velocity.clone();
                    int blocksToBreak = ViolentSprint.this.clamp((int)Math.round(speed / 0.35), 1, ViolentSprint.this.settings.maxTunnelLength);
                    int broken = ViolentSprint.this.breakTunnel((Entity)entity, entity.getLocation(), dir, blocksToBreak);
                    if (broken > 0) {
                        ViolentSprint.this.scheduleGuaranteedKnockback(entity, currentVelocity);
                    }
                }
                ++this.ticks;
            }
        }.runTaskTimer((Plugin)this, 1L, 1L);
    }

    private boolean isObstructed(Location loc) {
        Block feet = loc.getBlock();
        Block head = loc.clone().add(0.0, 1.0, 0.0).getBlock();
        return this.canBreak(feet) || this.canBreak(head);
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private void startMotionTracker() {
        new BukkitRunnable(){

            public void run() {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (!ViolentSprint.this.hasActiveAreaIn(p.getWorld())) {
                        ViolentSprint.this.motion.remove(p.getUniqueId());
                        continue;
                    }
                    Location now = p.getLocation();
                    Motion m = (Motion)ViolentSprint.this.motion.get(p.getUniqueId());
                    if (m == null) {
                        m = new Motion();
                        ViolentSprint.this.motion.put(p.getUniqueId(), m);
                    }
                    if (m.last != null && m.last.getWorld() == now.getWorld()) {
                        Vector d = now.toVector().subtract(m.last.toVector());
                        if (d.length() > 6.0) {
                            m.clear();
                        } else {
                            m.push(d);
                        }
                    } else {
                        m.clear();
                    }
                    m.last = now;
                }
            }
        }.runTaskTimer((Plugin)this, 1L, 1L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        this.motion.remove(id);
        this.pendingZoneByPlayer.remove(id);
    }

    private Vector velocityOf(Entity entity) {
        if (entity instanceof Player) {
            Motion m = this.motion.get(entity.getUniqueId());
            Vector v = m == null ? null : m.peak();
            return v != null ? v : new Vector(0, 0, 0);
        }
        return entity.getVelocity().clone();
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onImpactDamage(EntityDamageEvent event) {
        EntityDamageEvent.DamageCause cause = event.getCause();
        if (cause != EntityDamageEvent.DamageCause.FALL && cause != EntityDamageEvent.DamageCause.FLY_INTO_WALL) {
            return;
        }
        if (!(event.getEntity() instanceof LivingEntity)) {
            return;
        }
        LivingEntity entity = (LivingEntity)event.getEntity();
        if (!this.hasActiveAreaIn(entity.getWorld())) {
            return;
        }
        double damage = event.getDamage();
        if (cause == EntityDamageEvent.DamageCause.FALL) {
            if (damage < 4.0) {
                return;
            }
            int depth = damage >= 9.0 ? 2 : 1;
            this.breakVertical(entity.getLocation(), true, depth, 1.0);
        } else {
            if (damage < 3.0) {
                return;
            }
            this.handleElytraCrash(entity, damage);
        }
    }

    private void handleElytraCrash(LivingEntity entity, double damage) {
        int depth = this.clamp((int)Math.round(damage / 4.0), 1, 3);
        Vector dir = this.velocityOf((Entity)entity);
        if (dir.lengthSquared() < 0.04) {
            dir = entity.getLocation().getDirection();
        }
        dir = dir.clone().normalize();
        double intensity = Math.min(1.0, 0.6 + (double)depth * 0.2);
        if (Math.abs(dir.getY()) > 0.6) {
            this.breakVertical(entity.getLocation(), dir.getY() < 0.0, depth, intensity);
        } else {
            Vector horizontal = new Vector(dir.getX(), 0.0, dir.getZ());
            if (horizontal.lengthSquared() < 1.0E-6) {
                return;
            }
            this.breakTunnel(null, entity.getLocation(), horizontal.normalize(), depth);
        }
    }

    private int breakVertical(Location origin, boolean down, int depth, double baseIntensity) {
        World world = origin.getWorld();
        if (world == null) {
            return 0;
        }
        Vector push = new Vector(0, 1, 0);
        int bx = origin.getBlockX();
        int by = origin.getBlockY();
        int bz = origin.getBlockZ();
        int broken = 0;
        for (int i = 0; i < depth; ++i) {
            int y = down ? by - 1 - i : by + 2 + i;
            double intensity = Math.max(0.5, baseIntensity - (double)i * 0.25);
            for (int dx = -1; dx <= 1; ++dx) {
                for (int dz = -1; dz <= 1; ++dz) {
                    if (!this.tryBreakBlock(world.getBlockAt(bx + dx, y, bz + dz), push, null, intensity)) continue;
                    ++broken;
                }
            }
        }
        return broken;
    }

    private boolean handleSpear(LivingEntity attacker, LivingEntity target) {
        Vector toTarget = target.getLocation().toVector().subtract(attacker.getLocation().toVector());
        if (toTarget.lengthSquared() < 1.0E-6) {
            return false;
        }
        toTarget.normalize();
        double closing = this.velocityOf((Entity)attacker).subtract(this.velocityOf((Entity)target)).dot(toTarget);
        if (closing < 0.4) {
            return false;
        }
        if (!this.isInBreakArea(target.getLocation())) {
            return false;
        }
        Vector horizontal = new Vector(toTarget.getX(), 0.0, toTarget.getZ());
        if (horizontal.lengthSquared() < 1.0E-6) {
            return false;
        }
        double power = Math.min(2.5, 0.7 + (closing - 0.4) * 1.5);
        Vector kb = horizontal.normalize().multiply(power);
        kb.setY(0.35);
        Bukkit.getScheduler().runTask((Plugin)this, () -> {
            if (!target.isValid()) {
                return;
            }
            target.setVelocity(kb);
            this.handleKnockback((Entity)target, kb);
        });
        return true;
    }

    private int breakTunnel(Entity cause, Location origin, Vector direction, int length) {
        Vector step = direction.clone().normalize();
        int stepX = 0;
        if (step.getX() > 0.2) {
            stepX = 1;
        } else if (step.getX() < -0.2) {
            stepX = -1;
        }
        int stepZ = 0;
        if (step.getZ() > 0.2) {
            stepZ = 1;
        } else if (step.getZ() < -0.2) {
            stepZ = -1;
        }
        boolean diagonal = stepX != 0 && stepZ != 0;
        Vector right = new Vector(-step.getZ(), 0.0, step.getX()).normalize();
        int broken = 0;
        for (int i = 1; i <= length; ++i) {
            double intensity = Math.max(0.35, 1.0 - (double)(i - 1) * 0.15);
            if (diagonal) {
                broken += this.breakColumnAt(origin, i * stepX, 0, cause, step, intensity);
                broken += this.breakColumnAt(origin, 0, i * stepZ, cause, step, intensity);
                broken += this.breakColumnAt(origin, i * stepX, i * stepZ, cause, step, intensity);
                continue;
            }
            Location layerCenter = origin.clone().add(step.clone().multiply(i));
            for (int lateral = -1; lateral <= 1; ++lateral) {
                for (int vertical = 0; vertical <= 2; ++vertical) {
                    Location blockLoc = layerCenter.clone().add(right.clone().multiply(lateral)).add(0.0, (double)vertical, 0.0);
                    if (!this.tryBreakBlock(blockLoc.getBlock(), step, cause, intensity)) continue;
                    ++broken;
                }
            }
        }
        return broken;
    }

    private int breakColumnAt(Location origin, int dx, int dz, Entity cause, Vector pushVector, double intensity) {
        int broken = 0;
        for (int vertical = 0; vertical <= 2; ++vertical) {
            Location loc = origin.clone().add((double)dx, (double)vertical, (double)dz);
            if (!this.tryBreakBlock(loc.getBlock(), pushVector, cause, intensity)) continue;
            ++broken;
        }
        return broken;
    }

    private void scheduleGuaranteedKnockback(LivingEntity entity, Vector knockback) {
        Bukkit.getScheduler().runTask((Plugin)this, () -> {
            if (!entity.isValid()) {
                return;
            }
            entity.setVelocity(knockback);
            Bukkit.getScheduler().runTaskLater((Plugin)this, () -> this.confirmKnockback(entity, knockback), 1L);
        });
    }

    private void confirmKnockback(LivingEntity entity, Vector expected) {
        if (!entity.isValid()) {
            return;
        }
        double expectedHoriz = Math.hypot(expected.getX(), expected.getZ());
        if (expectedHoriz < 1.0E-4) {
            return;
        }
        Vector dir = new Vector(expected.getX(), 0.0, expected.getZ()).normalize();
        Vector actual = entity.getVelocity();
        double projection = actual.getX() * dir.getX() + actual.getZ() * dir.getZ();
        if (projection < expectedHoriz * 0.4) {
            entity.setVelocity(expected);
        }
    }

    private boolean isBreakable(Material type) {
        if (Compat.isAir(type)) {
            return false;
        }
        if (UNBREAKABLE_EXTRA.contains(type)) {
            return false;
        }
        if (!type.isSolid()) {
            return false;
        }
        return Compat.hardness(type) >= 0.0f;
    }

    private boolean canBreak(Block block) {
        Material type = block.getType();
        return this.isBreakable(type) && this.isAllowedAt(block.getLocation(), type);
    }

    private boolean isInBreakArea(Location loc) {
        if (!this.worldEnabled(loc.getWorld())) {
            return false;
        }
        if (this.breakEverywhere) {
            return true;
        }
        for (Zone zone : this.zones.values()) {
            if (!zone.enabled || !zone.contains(loc)) continue;
            return true;
        }
        return false;
    }

    private boolean isAllowedAt(Location loc, Material type) {
        if (!this.worldEnabled(loc.getWorld())) {
            return false;
        }
        if (this.globalProtected.contains(type)) {
            return false;
        }
        boolean allowed = this.breakEverywhere;
        for (Zone zone : this.zones.values()) {
            if (!zone.enabled || !zone.contains(loc)) continue;
            if (zone.protectedBlocks.contains(type)) {
                return false;
            }
            allowed = true;
        }
        return allowed;
    }

    private boolean tryBreakBlock(Block block, Vector pushVector, Entity cause, double intensity) {
        Material type = block.getType();
        if (!this.isBreakable(type)) {
            return false;
        }
        if (!this.isAllowedAt(block.getLocation(), type)) {
            return false;
        }
        if (this.pendingRegen.size() >= this.settings.maxPendingBlocks) {
            return false;
        }
        BlockState originalState = block.getState();
        if (this.settings.skipContainers && originalState instanceof InventoryHolder) {
            return false;
        }
        BlockData data = block.getBlockData();
        Location center = block.getLocation().add(0.5, 0.5, 0.5);
        World world = block.getWorld();
        this.spawnBreakEffect(world, center, data, pushVector, intensity);
        if (this.settings.sounds) {
            ThreadLocalRandom soundRnd = ThreadLocalRandom.current();
            float pitch = 0.65f + soundRnd.nextFloat() * 0.25f;
            Compat.play(world, center, Compat.breakSound(data), 1.5f, pitch);
            if (intensity >= 0.9) {
                float boomPitch = 0.5f + soundRnd.nextFloat() * 0.1f;
                Compat.play(world, center, Compat.S_EXPLODE, 0.5f, boomPitch);
            }
        }
        block.setType(Material.AIR, false);
        if (cause instanceof LivingEntity && !((LivingEntity)cause).isDead() && this.settings.selfDamagePerBlock > 0.0) {
            ((LivingEntity)cause).damage(this.settings.selfDamagePerBlock);
        }
        this.spawnDebrisFragments(world, center, data, pushVector, intensity);
        this.scheduleBlockRegen(originalState);
        return true;
    }

    private void scheduleBlockRegen(BlockState originalState) {
        this.pendingRegen.add(originalState);
        Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
            if (this.pendingRegen.remove(originalState)) {
                this.restore(originalState, true);
            }
        }, this.settings.regenDelayTicks);
    }

    private void restore(BlockState state, boolean withEffect) {
        World w = state.getWorld();
        if (w == null) {
            return;
        }
        Material current = w.getBlockAt(state.getX(), state.getY(), state.getZ()).getType();
        if (!Compat.isAir(current) && current.isSolid()) {
            return;
        }
        state.update(true, false);
        if (withEffect && this.settings.particles) {
            Compat.particle(w, Compat.P_BLOCK_CRUMBLE, new Location(w, (double)state.getX() + 0.5, (double)state.getY() + 0.5, (double)state.getZ() + 0.5), 15, 0.25, 0.25, 0.25, 0.05, state.getBlockData());
        }
    }

    @EventHandler
    public void onChunkUnload(ChunkUnloadEvent event) {
        if (this.pendingRegen.isEmpty()) {
            return;
        }
        Chunk chunk = event.getChunk();
        for (BlockState state : new ArrayList<BlockState>(this.pendingRegen)) {
            if (!state.getWorld().equals((Object)chunk.getWorld()) || state.getX() >> 4 != chunk.getX() || state.getZ() >> 4 != chunk.getZ()) continue;
            this.pendingRegen.remove(state);
            this.restore(state, false);
        }
    }

    private void spawnBreakEffect(World world, Location center, BlockData data, Vector pushVector, double intensity) {
        int i;
        if (!this.settings.particles) {
            return;
        }
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        int coreCount = this.clamp((int)Math.round(10.0 * intensity), 4, 10);
        Compat.particle(world, Compat.P_BLOCK, center, coreCount, 0.22, 0.22, 0.22, 0.03, data);
        if (intensity >= 0.5) {
            int ringPoints = this.clamp((int)Math.round(8.0 * intensity), 4, 8);
            double ringRadius = 0.4;
            for (i = 0; i < ringPoints; ++i) {
                double angle = Math.PI * 2 / (double)ringPoints * (double)i;
                Compat.particle(world, Compat.P_CRIT, center.clone().add(Math.cos(angle) * ringRadius, -0.15, Math.sin(angle) * ringRadius), 1, 0.0, 0.0, 0.0, 0.0);
            }
        }
        int dustCount = this.clamp((int)Math.round(6.0 * intensity), 2, 6);
        Compat.particle(world, Compat.P_CLOUD, center, dustCount, 0.25, 0.15, 0.25, 0.015);
        if (intensity >= 0.9) {
            Compat.particle(world, Compat.P_FLASH, center, 1, 0.0, 0.0, 0.0, 0.0);
            Compat.particle(world, Compat.P_ENCHANTED_HIT, center, 10, 0.35, 0.35, 0.35, 0.08);
            int outerRingPoints = 6;
            double outerRadius = 0.65;
            for (int i2 = 0; i2 < outerRingPoints; ++i2) {
                double angle = Math.PI * 2 / (double)outerRingPoints * (double)i2 + 0.3;
                Compat.particle(world, Compat.P_CRIT, center.clone().add(Math.cos(angle) * outerRadius, 0.1, Math.sin(angle) * outerRadius), 1, 0.0, 0.0, 0.0, 0.0);
            }
        }
        int debrisCount = this.clamp((int)Math.round(6.0 * intensity), 2, 6);
        Vector base = pushVector.clone().normalize();
        for (i = 0; i < debrisCount; ++i) {
            double speed = 0.25 + rnd.nextDouble() * 0.25;
            double dx = base.getX() + (rnd.nextDouble() - 0.5) * 0.6;
            double dy = 0.25 + rnd.nextDouble() * 0.4;
            double dz = base.getZ() + (rnd.nextDouble() - 0.5) * 0.6;
            Compat.particle(world, Compat.P_BLOCK_CRUMBLE, center, 0, dx, dy, dz, speed, data);
        }
    }

    private void spawnDebrisFragments(World world, Location center, BlockData data, Vector pushVector, double intensity) {
        if (!this.settings.fragmentsEnabled || !Compat.DISPLAY_SUPPORTED) {
            return;
        }
        int room = this.settings.maxActiveFragments - this.fragments.size();
        if (room <= 0) {
            return;
        }
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        int count = Math.min(room, rnd.nextInt(3, 6));
        for (int i = 0; i < count; ++i) {
            float scale;
            double ox = (rnd.nextDouble() - 0.5) * 0.4;
            double oy = (rnd.nextDouble() - 0.5) * 0.4;
            double oz = (rnd.nextDouble() - 0.5) * 0.4;
            Location spawnLoc = center.clone().add(ox, oy, oz);
            Entity display = Compat.spawnFragment(world, spawnLoc, data, scale = 0.25f + rnd.nextFloat() * 0.2f);
            if (display == null) {
                return;
            }
            Vector vel = pushVector.clone().multiply((0.5 + rnd.nextDouble() * 0.2) * (0.7 + intensity * 0.5));
            vel.setY(0.3 + rnd.nextDouble() * 0.25);
            vel.setX(vel.getX() + (rnd.nextDouble() - 0.5) * 0.25);
            vel.setZ(vel.getZ() + (rnd.nextDouble() - 0.5) * 0.25);
            float spinX = (rnd.nextFloat() - 0.5f) * 0.9f;
            float spinY = (rnd.nextFloat() - 0.5f) * 0.9f;
            float spinZ = (rnd.nextFloat() - 0.5f) * 0.9f;
            this.fragments.add(new Fragment(display, vel, scale, spinX, spinY, spinZ));
        }
    }

    private void startFragmentTicker() {
        new BukkitRunnable(){

            public void run() {
                if (ViolentSprint.this.fragments.isEmpty()) {
                    return;
                }
                Iterator it = ViolentSprint.this.fragments.iterator();
                while (it.hasNext()) {
                    if (ViolentSprint.this.stepFragment((Fragment)it.next())) continue;
                    it.remove();
                }
            }
        }.runTaskTimer((Plugin)this, 1L, 1L);
    }

    private boolean stepFragment(Fragment f) {
        Entity display = f.display;
        if (!display.isValid() || f.ticks >= this.settings.fragmentLifetimeTicks) {
            if (display.isValid()) {
                display.remove();
            }
            return false;
        }
        f.velocity.setY(f.velocity.getY() - 0.04);
        f.velocity.multiply(0.97);
        Location next = display.getLocation().add(f.velocity);
        if (next.getBlock().getType().isSolid()) {
            display.remove();
            return false;
        }
        display.teleport(next);
        f.angle += 0.35f;
        Compat.rotateFragment(display, f.scale, f.angle, f.ax, f.ay, f.az);
        if (this.settings.fragmentDamage > 0.0) {
            for (Entity nearby : next.getWorld().getNearbyEntities(next, 0.6, 0.6, 0.6)) {
                LivingEntity living;
                if (!(nearby instanceof LivingEntity) || nearby instanceof ArmorStand || !f.alreadyHit.add((living = (LivingEntity)nearby).getUniqueId())) continue;
                living.damage(this.settings.fragmentDamage);
            }
        }
        ++f.ticks;
        return true;
    }

    static Material parseMaterial(String raw) {
        if (raw == null) {
            return null;
        }
        String text = raw.trim();
        if (text.isEmpty()) {
            return null;
        }
        Material m = Material.matchMaterial((String)text);
        if (m == null) {
            m = Material.getMaterial((String)text.toUpperCase(Locale.ROOT).replace(' ', '_'));
        }
        if (m == null || m.name().startsWith("LEGACY_")) {
            return null;
        }
        return m;
    }

    String createZone(String rawName, String world) {
        String name = rawName.toLowerCase(Locale.ROOT);
        if (!ZONE_NAME.matcher(name).matches()) {
            return "Nome non valido: usa minuscole, numeri, - e _ (max 20 caratteri, niente spazi).";
        }
        if (this.zones.containsKey(name)) {
            return "Esiste gi\u00e0 una zona chiamata '" + name + "'.";
        }
        this.zones.put(name, new Zone(name, world));
        this.saveZonesConfig();
        return null;
    }

    String renameZone(Zone zone, String rawNew) {
        String name = rawNew.toLowerCase(Locale.ROOT);
        if (!ZONE_NAME.matcher(name).matches()) {
            return "Nome non valido: usa minuscole, numeri, - e _ (max 20 caratteri, niente spazi).";
        }
        if (!name.equals(zone.name) && this.zones.containsKey(name)) {
            return "Esiste gi\u00e0 una zona chiamata '" + name + "'.";
        }
        String old = zone.name;
        this.zones.remove(old);
        zone.name = name;
        this.zones.put(name, zone);
        for (Map.Entry<UUID, String> e : this.pendingZoneByPlayer.entrySet()) {
            if (!old.equals(e.getValue())) continue;
            e.setValue(name);
        }
        this.saveZonesConfig();
        return null;
    }

    String deleteZone(String rawName) {
        String name = rawName.toLowerCase(Locale.ROOT);
        if (this.zones.remove(name) == null) {
            return "Nessuna zona chiamata '" + name + "'.";
        }
        this.pendingZoneByPlayer.values().removeIf(v -> v.equals(name));
        this.saveZonesConfig();
        return null;
    }

    String setCorner(Zone zone, int index, Location loc) {
        if (loc.getWorld() == null) {
            return "Mondo non valido.";
        }
        String worldName = loc.getWorld().getName();
        if (zone.corner1 == null && zone.corner2 == null) {
            zone.world = worldName;
        } else if (!zone.world.equals(worldName)) {
            return "Devi essere nel mondo '" + zone.world + "' (dove \u00e8 la zona).";
        }
        int[] corner = new int[]{loc.getBlockX(), loc.getBlockY(), loc.getBlockZ()};
        if (index == 1) {
            zone.corner1 = corner;
        } else {
            zone.corner2 = corner;
        }
        this.saveZonesConfig();
        return null;
    }

    void loadZonesConfig() {
        if (!this.getDataFolder().exists()) {
            this.getDataFolder().mkdirs();
        }
        this.zonesFile = new File(this.getDataFolder(), "zones.yml");
        if (!this.zonesFile.exists()) {
            try {
                this.zonesFile.createNewFile();
            }
            catch (IOException e) {
                this.getLogger().warning("Impossibile creare zones.yml: " + e.getMessage());
            }
        }
        this.zonesConfig = YamlConfiguration.loadConfiguration((File)this.zonesFile);
        this.breakEverywhere = this.zonesConfig.getBoolean("break-everywhere", false);
        this.globalProtected.clear();
        this.readMaterials(this.zonesConfig.getStringList("protected-blocks"), this.globalProtected);
        this.zones.clear();
        ConfigurationSection zonesSection = this.zonesConfig.getConfigurationSection("zones");
        if (zonesSection != null) {
            for (String name : zonesSection.getKeys(false)) {
                ConfigurationSection zs = zonesSection.getConfigurationSection(name);
                if (zs == null) continue;
                Zone zone = new Zone(name, zs.getString("world", "world"));
                zone.corner1 = this.toIntArray(zs.getIntegerList("corner1"));
                zone.corner2 = this.toIntArray(zs.getIntegerList("corner2"));
                zone.enabled = zs.getBoolean("enabled", true);
                this.readMaterials(zs.getStringList("protected-blocks"), zone.protectedBlocks);
                this.zones.put(name, zone);
            }
        }
    }

    private void readMaterials(List<String> names, Set<Material> target) {
        for (String n : names) {
            Material m = ViolentSprint.parseMaterial(n);
            if (m != null) {
                target.add(m);
                continue;
            }
            this.getLogger().warning("Materiale sconosciuto in zones.yml: " + n);
        }
    }

    private List<String> materialNames(Set<Material> set) {
        ArrayList<String> out = new ArrayList<String>();
        for (Material m : set) {
            out.add(m.name());
        }
        Collections.sort(out);
        return out;
    }

    void saveZonesConfig() {
        this.zonesConfig.set("break-everywhere", (Object)this.breakEverywhere);
        this.zonesConfig.set("protected-blocks", this.materialNames(this.globalProtected));
        this.zonesConfig.set("zones", null);
        for (Zone zone : this.zones.values()) {
            String path = "zones." + zone.name;
            this.zonesConfig.set(path + ".world", (Object)zone.world);
            this.zonesConfig.set(path + ".enabled", (Object)zone.enabled);
            this.zonesConfig.set(path + ".protected-blocks", this.materialNames(zone.protectedBlocks));
            if (zone.corner1 != null) {
                this.zonesConfig.set(path + ".corner1", Arrays.asList(zone.corner1[0], zone.corner1[1], zone.corner1[2]));
            }
            if (zone.corner2 == null) continue;
            this.zonesConfig.set(path + ".corner2", Arrays.asList(zone.corner2[0], zone.corner2[1], zone.corner2[2]));
        }
        try {
            this.zonesConfig.save(this.zonesFile);
        }
        catch (IOException e) {
            this.getLogger().warning("Impossibile salvare zones.yml: " + e.getMessage());
        }
    }

    private int[] toIntArray(List<Integer> list) {
        if (list == null || list.size() < 3) {
            return null;
        }
        return new int[]{list.get(0), list.get(1), list.get(2)};
    }

    private static final class Fragment {
        final Entity display;
        final Vector velocity;
        final float scale;
        final float ax;
        final float ay;
        final float az;
        final Set<UUID> alreadyHit = new HashSet<UUID>();
        int ticks = 0;
        float angle = 0.0f;

        Fragment(Entity display, Vector velocity, float scale, float spinX, float spinY, float spinZ) {
            this.display = display;
            this.velocity = velocity;
            this.scale = scale;
            float len = (float)Math.sqrt(spinX * spinX + spinY * spinY + spinZ * spinZ);
            if (len < 1.0E-4f) {
                this.ax = 0.0f;
                this.ay = 1.0f;
                this.az = 0.0f;
            } else {
                this.ax = spinX / len;
                this.ay = spinY / len;
                this.az = spinZ / len;
            }
        }
    }

    private static final class Motion {
        Location last;
        final Vector[] ring = new Vector[4];
        int idx = 0;

        private Motion() {
        }

        void push(Vector v) {
            this.ring[this.idx] = v;
            this.idx = (this.idx + 1) % this.ring.length;
        }

        void clear() {
            for (int i = 0; i < this.ring.length; ++i) {
                this.ring[i] = null;
            }
        }

        Vector peak() {
            Vector best = null;
            for (Vector v : this.ring) {
                if (v == null || best != null && !(v.lengthSquared() > best.lengthSquared())) continue;
                best = v;
            }
            return best == null ? null : best.clone();
        }
    }
}

