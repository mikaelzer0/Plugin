package io.github.mikaelzer0.violentsprint;

import io.github.mikaelzer0.violentsprint.Compat;
import io.github.mikaelzer0.violentsprint.Msg;
import io.github.mikaelzer0.violentsprint.ViolentSprint;
import io.github.mikaelzer0.violentsprint.Zone;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

final class Commands
implements CommandExecutor,
TabCompleter {
    private static final List<String> ZONE_SUBS = Arrays.asList("list", "create", "pos1", "pos2", "remove", "rename", "on", "off", "toggle", "tp", "show", "info", "block");
    private static final List<String> ZONE_SUBS_WITH_NAME = Arrays.asList("pos1", "pos2", "remove", "delete", "rename", "on", "off", "toggle", "tp", "show", "info", "block");
    private static final List<String> BLOCK_ACTIONS = Arrays.asList("add", "remove", "list", "clear");
    private final ViolentSprint plugin;

    Commands(ViolentSprint plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (this.noPermission(sender)) {
            return true;
        }
        switch (name) {
            case "vs": {
                return this.vs(sender, args);
            }
            case "row": {
                this.setUniversal(sender, !this.plugin.breakEverywhere);
                return true;
            }
            case "tlist": {
                return this.zoneList(sender);
            }
            case "tcreate": {
                if (args.length < 1) {
                    Msg.send(sender, "\u00a7eUso: /tcreate <nome>");
                    return true;
                }
                return this.zoneCreate(sender, args[0]);
            }
            case "t1": {
                return this.zoneCorner(sender, 1, null);
            }
            case "t2": {
                return this.zoneCorner(sender, 2, null);
            }
            case "tremove": {
                if (args.length < 1) {
                    Msg.send(sender, "\u00a7eUso: /tremove <nome>");
                    return true;
                }
                return this.zoneRemove(sender, args[0]);
            }
        }
        return false;
    }

    private boolean noPermission(CommandSender sender) {
        if (!ViolentSprint.isAdmin(sender)) {
            sender.sendMessage("Unknown command. Type \"/help\" for help.");
            return true;
        }
        return false;
    }

    private static String[] tail(String[] a, int from) {
        return a.length <= from ? new String[]{} : Arrays.copyOfRange(a, from, a.length);
    }

    private boolean vs(CommandSender sender, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("menu")) {
            if (!(sender instanceof Player)) {
                Msg.send(sender, "\u00a7cIl menu si apre solo in gioco. Usa /vs help per i comandi.");
                return true;
            }
            this.plugin.menus.openMain((Player)sender);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "zone": 
            case "zona": {
                return this.zone(sender, Commands.tail(args, 1));
            }
            case "universal": 
            case "universale": 
            case "global": {
                return this.universal(sender, Commands.tail(args, 1));
            }
            case "status": 
            case "stato": {
                Msg.send(sender, "\u00a76Stato del plugin:");
                for (String line : this.plugin.statusLines()) {
                    sender.sendMessage(" " + line);
                }
                return true;
            }
            case "reload": {
                this.plugin.reloadAll();
                this.plugin.audit(sender, "configurazione ricaricata");
                Msg.send(sender, "\u00a7aConfig e zone ricaricate (" + this.plugin.zones.size() + " zone).");
                return true;
            }
        }
        this.help(sender);
        return true;
    }

    private void help(CommandSender s) {
        s.sendMessage("\u00a78\u00a7m      \u00a7r \u00a76ViolentSprint \u00a78\u00a7m      ");
        s.sendMessage("\u00a7e/vs \u00a77apre il menu (zone, universale, blocchi protetti)");
        s.sendMessage("\u00a7e/vs status \u00a77stato, limiti e carico del plugin");
        s.sendMessage("\u00a7e/vs zone \u00a77list | create <n> | pos1|pos2 [n] | remove <n> | rename <n> <nuovo>");
        s.sendMessage("\u00a7e/vs zone \u00a77on|off|toggle <n> | tp <n> | show <n> | info <n>");
        s.sendMessage("\u00a7e/vs zone block <n> \u00a77add|remove|list|clear [MATERIALE]");
        s.sendMessage("\u00a7e/vs universal \u00a77[on|off|toggle|status]");
        s.sendMessage("\u00a7e/vs universal block \u00a77add|remove|list|clear [MATERIALE]");
        s.sendMessage("\u00a7e/vs reload \u00a77ricarica config.yml e zones.yml");
        s.sendMessage("\u00a78Menu e comandi sono riservati agli OP.");
    }

    private boolean zone(CommandSender sender, String[] a) {
        String sub;
        if (a.length == 0) {
            this.help(sender);
            return true;
        }
        switch (sub = a[0].toLowerCase(Locale.ROOT)) {
            case "list": {
                return this.zoneList(sender);
            }
            case "create": {
                if (a.length < 2) {
                    Msg.send(sender, "\u00a7eUso: /vs zone create <nome>");
                    return true;
                }
                return this.zoneCreate(sender, a[1]);
            }
            case "pos1": 
            case "pos2": {
                return this.zoneCorner(sender, sub.equals("pos1") ? 1 : 2, a.length > 1 ? a[1] : null);
            }
            case "remove": 
            case "delete": {
                if (a.length < 2) {
                    Msg.send(sender, "\u00a7eUso: /vs zone remove <nome>");
                    return true;
                }
                return this.zoneRemove(sender, a[1]);
            }
            case "rename": {
                if (a.length < 3) {
                    Msg.send(sender, "\u00a7eUso: /vs zone rename <nome> <nuovo>");
                    return true;
                }
                Zone z = this.find(sender, a[1]);
                if (z == null) {
                    return true;
                }
                String err = this.plugin.renameZone(z, a[2]);
                Msg.send(sender, err == null ? "\u00a7aZona rinominata in '" + z.name + "'." : "\u00a7c" + err);
                return true;
            }
            case "on": 
            case "off": 
            case "toggle": {
                if (a.length < 2) {
                    Msg.send(sender, "\u00a7eUso: /vs zone " + sub + " <nome>");
                    return true;
                }
                Zone z = this.find(sender, a[1]);
                if (z == null) {
                    return true;
                }
                z.enabled = sub.equals("toggle") ? !z.enabled : sub.equals("on");
                this.plugin.saveZonesConfig();
                this.plugin.audit(sender, "zona '" + z.name + "' " + (z.enabled ? "attivata" : "disattivata"));
                Msg.send(sender, "\u00a77Zona '" + z.name + "': " + (z.enabled ? "\u00a7aATTIVA" : "\u00a7cDISATTIVATA"));
                return true;
            }
            case "tp": {
                if (!(sender instanceof Player)) {
                    Msg.send(sender, "\u00a7cQuesto comando si pu\u00f2 usare solo in gioco.");
                    return true;
                }
                if (a.length < 2) {
                    Msg.send(sender, "\u00a7eUso: /vs zone tp <nome>");
                    return true;
                }
                Zone z = this.find(sender, a[1]);
                if (z != null) {
                    this.plugin.menus.teleport((Player)sender, z);
                }
                return true;
            }
            case "show": {
                if (!(sender instanceof Player)) {
                    Msg.send(sender, "\u00a7cQuesto comando si pu\u00f2 usare solo in gioco.");
                    return true;
                }
                if (a.length < 2) {
                    Msg.send(sender, "\u00a7eUso: /vs zone show <nome>");
                    return true;
                }
                Zone z = this.find(sender, a[1]);
                if (z != null) {
                    this.plugin.menus.showBorders((Player)sender, z);
                }
                return true;
            }
            case "info": {
                if (a.length < 2) {
                    Msg.send(sender, "\u00a7eUso: /vs zone info <nome>");
                    return true;
                }
                Zone z = this.find(sender, a[1]);
                if (z == null) {
                    return true;
                }
                Msg.send(sender, "\u00a76Zona \u00a7f" + z.name + " \u00a77[" + z.world + "] " + (!z.isComplete() ? "\u00a7eincompleta" : (z.enabled ? "\u00a7aattiva" : "\u00a7cdisattivata")));
                Msg.send(sender, "\u00a77Angolo 1: \u00a7f" + Zone.fmt(z.corner1) + " \u00a77- Angolo 2: \u00a7f" + Zone.fmt(z.corner2));
                if (z.isComplete()) {
                    Msg.send(sender, "\u00a77Dimensioni: \u00a7f" + z.sizeX() + "x" + z.sizeY() + "x" + z.sizeZ());
                }
                Msg.send(sender, "\u00a77Blocchi protetti: \u00a7f" + Commands.joinMaterials(z.protectedBlocks));
                return true;
            }
            case "block": {
                if (a.length < 3) {
                    Msg.send(sender, "\u00a7eUso: /vs zone block <nome> add|remove|list|clear [MATERIALE]");
                    return true;
                }
                Zone z = this.find(sender, a[1]);
                if (z == null) {
                    return true;
                }
                this.blockCmd(sender, z.protectedBlocks, "zona " + z.name, Commands.tail(a, 2));
                return true;
            }
        }
        this.help(sender);
        return true;
    }

    private Zone find(CommandSender sender, String rawName) {
        Zone z = this.plugin.zones.get(rawName.toLowerCase(Locale.ROOT));
        if (z == null) {
            Msg.send(sender, "\u00a7cNessuna zona chiamata '" + rawName + "'. Vedi /vs zone list.");
        }
        return z;
    }

    private boolean zoneList(CommandSender sender) {
        Msg.send(sender, this.plugin.breakEverywhere ? "\u00a7aModalit\u00e0 universale ATTIVA: la rottura funziona ovunque (le zone servono solo per i blocchi protetti)." : "\u00a7eModalit\u00e0 universale spenta: la rottura funziona solo nelle zone attive.");
        if (this.plugin.zones.isEmpty()) {
            Msg.send(sender, "\u00a77Nessuna zona bersaglio definita.");
            return true;
        }
        Msg.send(sender, "\u00a76Zone bersaglio (" + this.plugin.zones.size() + "):");
        for (Zone z : this.plugin.zones.values()) {
            String stato = !z.isComplete() ? "\u00a7eincompleta (manca un angolo)" : (z.enabled ? "\u00a7aattiva" : "\u00a7cdisattivata");
            Msg.send(sender, " \u00a77- \u00a7f" + z.name + " \u00a77[" + z.world + "] " + stato + " \u00a77| protetti: \u00a7f" + z.protectedBlocks.size());
        }
        return true;
    }

    private boolean zoneCreate(CommandSender sender, String name) {
        if (!(sender instanceof Player)) {
            Msg.send(sender, "\u00a7cQuesto comando si pu\u00f2 usare solo in gioco.");
            return true;
        }
        Player p = (Player)sender;
        String err = this.plugin.createZone(name, p.getWorld().getName());
        if (err != null) {
            Msg.send((CommandSender)p, "\u00a7c" + err);
            return true;
        }
        this.plugin.audit((CommandSender)p, "zona '" + name.toLowerCase(Locale.ROOT) + "' creata");
        String n = name.toLowerCase(Locale.ROOT);
        this.plugin.pendingZoneByPlayer.put(p.getUniqueId(), n);
        Msg.send((CommandSender)p, "\u00a7aZona '" + n + "' creata nel mondo '" + p.getWorld().getName() + "'.");
        Msg.send((CommandSender)p, "\u00a77Ora vai nel primo angolo e usa /vs zone pos1, poi nell'altro e usa /vs zone pos2 (oppure /vs per il menu).");
        return true;
    }

    private boolean zoneCorner(CommandSender sender, int index, String rawName) {
        String name;
        if (!(sender instanceof Player)) {
            Msg.send(sender, "\u00a7cQuesto comando si pu\u00f2 usare solo in gioco.");
            return true;
        }
        Player p = (Player)sender;
        String string = name = rawName != null ? rawName.toLowerCase(Locale.ROOT) : this.plugin.pendingZoneByPlayer.get(p.getUniqueId());
        if (name == null) {
            Msg.send((CommandSender)p, "\u00a7cPrima crea una zona con /vs zone create <nome> (o indica il nome della zona).");
            return true;
        }
        Zone z = this.plugin.zones.get(name);
        if (z == null) {
            Msg.send((CommandSender)p, "\u00a7cLa zona '" + name + "' non esiste.");
            return true;
        }
        String err = this.plugin.setCorner(z, index, p.getLocation());
        if (err != null) {
            Msg.send((CommandSender)p, "\u00a7c" + err);
            return true;
        }
        this.plugin.pendingZoneByPlayer.put(p.getUniqueId(), z.name);
        Msg.send((CommandSender)p, "\u00a7aAngolo " + index + " di '" + z.name + "' impostato.");
        if (z.isComplete()) {
            Msg.send((CommandSender)p, "\u00a76Zona '" + z.name + "' completa! Dentro quell'area il knockback ora rompe i blocchi.");
        }
        return true;
    }

    private boolean zoneRemove(CommandSender sender, String name) {
        String err = this.plugin.deleteZone(name);
        if (err == null) {
            this.plugin.audit(sender, "zona '" + name.toLowerCase(Locale.ROOT) + "' rimossa");
        }
        Msg.send(sender, err == null ? "\u00a7aZona '" + name.toLowerCase(Locale.ROOT) + "' rimossa." : "\u00a7c" + err);
        return true;
    }

    private boolean universal(CommandSender sender, String[] a) {
        if (a.length == 0 || a[0].equalsIgnoreCase("status")) {
            Msg.send(sender, this.plugin.breakEverywhere ? "\u00a7aModalit\u00e0 universale: ATTIVA \u00a77(rottura ovunque, in tutti i mondi)" : "\u00a7eModalit\u00e0 universale: SPENTA \u00a77(solo dentro le zone attive)");
            Msg.send(sender, "\u00a77Blocchi protetti universali: \u00a7f" + Commands.joinMaterials(this.plugin.globalProtected));
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "on": {
                this.setUniversal(sender, true);
                return true;
            }
            case "off": {
                this.setUniversal(sender, false);
                return true;
            }
            case "toggle": {
                this.setUniversal(sender, !this.plugin.breakEverywhere);
                return true;
            }
            case "block": {
                this.blockCmd(sender, this.plugin.globalProtected, "universale", Commands.tail(a, 1));
                return true;
            }
        }
        this.help(sender);
        return true;
    }

    private void setUniversal(CommandSender sender, boolean on) {
        this.plugin.setBreakEverywhere(sender, on);
        Msg.send(sender, on ? "\u00a7aRottura da knockback ora ATTIVA OVUNQUE \u00a77(in tutti i mondi non esclusi dal config)." : "\u00a7eRottura da knockback ora limitata alle zone bersaglio attive.");
    }

    private void blockCmd(CommandSender s, Set<Material> set, String scope, String[] a) {
        String action;
        if (a.length == 0) {
            Msg.send(s, "\u00a7eUso: block add|remove|list|clear [MATERIALE]");
            return;
        }
        switch (action = a[0].toLowerCase(Locale.ROOT)) {
            case "list": {
                Msg.send(s, "\u00a76Blocchi protetti (" + scope + "): \u00a7f" + Commands.joinMaterials(set));
                return;
            }
            case "clear": {
                set.clear();
                this.plugin.saveZonesConfig();
                this.plugin.audit(s, "lista blocchi protetti (" + scope + ") svuotata");
                Msg.send(s, "\u00a7aLista blocchi protetti (" + scope + ") svuotata.");
                return;
            }
            case "add": 
            case "remove": {
                Material m = this.resolveMaterial(s, a.length > 1 ? a[1] : null);
                if (m == null) {
                    return;
                }
                if (action.equals("add")) {
                    if (!m.isBlock() || Compat.isAir(m)) {
                        Msg.send(s, "\u00a7c" + m.name() + " non \u00e8 un blocco.");
                        return;
                    }
                    Msg.send(s, set.add(m) ? "\u00a7aAggiunto \u00a7f" + m.name() + "\u00a7a ai blocchi protetti (" + scope + ")." : "\u00a77" + m.name() + " era gi\u00e0 in lista (" + scope + ").");
                } else {
                    Msg.send(s, set.remove(m) ? "\u00a7aRimosso \u00a7f" + m.name() + "\u00a7a dai blocchi protetti (" + scope + ")." : "\u00a77" + m.name() + " non era in lista (" + scope + ").");
                }
                this.plugin.saveZonesConfig();
                return;
            }
        }
        Msg.send(s, "\u00a7eUso: block add|remove|list|clear [MATERIALE]");
    }

    private Material resolveMaterial(CommandSender s, String arg) {
        if (arg == null) {
            ItemStack hand;
            if (s instanceof Player && (hand = ((Player)s).getInventory().getItemInMainHand()) != null && hand.getType() != Material.AIR) {
                return hand.getType();
            }
            Msg.send(s, "\u00a7eIndica un MATERIALE (es. OBSIDIAN) oppure tieni un blocco in mano.");
            return null;
        }
        Material m = ViolentSprint.parseMaterial(arg);
        if (m == null) {
            Msg.send(s, "\u00a7cMateriale sconosciuto: '" + arg + "'.");
        }
        return m;
    }

    private static String joinMaterials(Set<Material> set) {
        if (set.isEmpty()) {
            return "nessuno";
        }
        ArrayList<String> names = new ArrayList<String>();
        for (Material m : set) {
            names.add(m.name());
        }
        Collections.sort(names);
        return String.join((CharSequence)", ", names);
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] a) {
        if (!ViolentSprint.isAdmin(sender)) {
            return Collections.emptyList();
        }
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        if (cmd.equals("tremove")) {
            return a.length == 1 ? Commands.filter(new ArrayList<String>(this.plugin.zones.keySet()), a[0]) : Collections.emptyList();
        }
        if (!cmd.equals("vs")) {
            return Collections.emptyList();
        }
        if (a.length == 1) {
            return Commands.filter(Arrays.asList("menu", "zone", "universal", "status", "reload", "help"), a[0]);
        }
        String first = a[0].toLowerCase(Locale.ROOT);
        if (first.equals("zone") || first.equals("zona")) {
            if (a.length == 2) {
                return Commands.filter(ZONE_SUBS, a[1]);
            }
            String sub = a[1].toLowerCase(Locale.ROOT);
            if (a.length == 3 && ZONE_SUBS_WITH_NAME.contains(sub)) {
                return Commands.filter(new ArrayList<String>(this.plugin.zones.keySet()), a[2]);
            }
            if (sub.equals("block")) {
                if (a.length == 4) {
                    return Commands.filter(BLOCK_ACTIONS, a[3]);
                }
                if (a.length == 5) {
                    Zone z = this.plugin.zones.get(a[2].toLowerCase(Locale.ROOT));
                    return this.materialCompletions(a[3], z == null ? null : z.protectedBlocks, a[4]);
                }
            }
        } else if (first.equals("universal") || first.equals("universale") || first.equals("global")) {
            if (a.length == 2) {
                return Commands.filter(Arrays.asList("on", "off", "toggle", "status", "block"), a[1]);
            }
            if (a[1].equalsIgnoreCase("block")) {
                if (a.length == 3) {
                    return Commands.filter(BLOCK_ACTIONS, a[2]);
                }
                if (a.length == 4) {
                    return this.materialCompletions(a[2], this.plugin.globalProtected, a[3]);
                }
            }
        }
        return Collections.emptyList();
    }

    private List<String> materialCompletions(String action, Set<Material> current, String prefix) {
        String p = prefix.toUpperCase(Locale.ROOT);
        ArrayList<String> out = new ArrayList<String>();
        if (action.equalsIgnoreCase("remove")) {
            if (current != null) {
                for (Material m : current) {
                    if (!m.name().startsWith(p)) continue;
                    out.add(m.name());
                }
            }
        } else if (action.equalsIgnoreCase("add")) {
            for (Material m : Material.values()) {
                if (out.size() < 40) {
                    if (!m.isBlock() || m.name().startsWith("LEGACY_") || !m.name().startsWith(p)) continue;
                    out.add(m.name());
                    continue;
                }
                break;
            }
        }
        Collections.sort(out);
        return out;
    }

    private static List<String> filter(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        ArrayList<String> out = new ArrayList<String>();
        for (String o : options) {
            if (!o.toLowerCase(Locale.ROOT).startsWith(p)) continue;
            out.add(o);
        }
        return out;
    }
}

