package io.github.mikaelzer0.violentsprint;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import org.bukkit.configuration.file.FileConfiguration;

final class Settings {
    boolean auditLog = true;
    final Set<String> disabledWorlds = new HashSet<String>();
    int maxPendingBlocks = 2500;
    int maxActiveFragments = 80;
    long regenDelayTicks = 160L;
    boolean skipContainers = true;
    double selfDamagePerBlock = 1.0;
    double minKnockbackForce = 0.7;
    int maxTunnelLength = 4;
    boolean fragmentsEnabled = true;
    double fragmentDamage = 1.0;
    int fragmentLifetimeTicks = 30;
    boolean particles = true;
    boolean sounds = true;

    Settings() {
    }

    void load(FileConfiguration c) {
        this.auditLog = c.getBoolean("audit-log", true);
        this.disabledWorlds.clear();
        for (String w : c.getStringList("disabled-worlds")) {
            this.disabledWorlds.add(w.toLowerCase(Locale.ROOT));
        }
        this.maxPendingBlocks = Math.max(0, c.getInt("limits.max-pending-blocks", 2500));
        this.maxActiveFragments = Math.max(0, c.getInt("limits.max-active-fragments", 80));
        this.regenDelayTicks = Math.max(20L, Math.round(c.getDouble("breaking.regen-delay-seconds", 8.0) * 20.0));
        this.skipContainers = c.getBoolean("breaking.skip-containers", true);
        this.selfDamagePerBlock = Math.max(0.0, c.getDouble("breaking.self-damage-per-block", 1.0));
        this.minKnockbackForce = Math.max(0.1, c.getDouble("breaking.min-knockback-force", 0.7));
        this.maxTunnelLength = Math.max(1, Math.min(8, c.getInt("breaking.max-tunnel-length", 4)));
        this.fragmentsEnabled = c.getBoolean("fragments.enabled", true);
        this.fragmentDamage = Math.max(0.0, c.getDouble("fragments.damage", 1.0));
        this.fragmentLifetimeTicks = Math.max(5, Math.min(100, c.getInt("fragments.lifetime-ticks", 30)));
        this.particles = c.getBoolean("effects.particles", true);
        this.sounds = c.getBoolean("effects.sounds", true);
    }
}

