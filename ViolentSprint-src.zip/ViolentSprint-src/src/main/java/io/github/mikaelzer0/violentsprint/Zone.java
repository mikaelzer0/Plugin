package io.github.mikaelzer0.violentsprint;

import java.util.EnumSet;
import java.util.Set;
import org.bukkit.Location;
import org.bukkit.Material;

final class Zone {
    String name;
    String world;
    int[] corner1;
    int[] corner2;
    boolean enabled = true;
    final Set<Material> protectedBlocks = EnumSet.noneOf(Material.class);

    Zone(String name, String world) {
        this.name = name;
        this.world = world;
    }

    boolean isComplete() {
        return this.corner1 != null && this.corner2 != null;
    }

    int minX() {
        return Math.min(this.corner1[0], this.corner2[0]);
    }

    int minY() {
        return Math.min(this.corner1[1], this.corner2[1]);
    }

    int minZ() {
        return Math.min(this.corner1[2], this.corner2[2]);
    }

    int maxX() {
        return Math.max(this.corner1[0], this.corner2[0]);
    }

    int maxY() {
        return Math.max(this.corner1[1], this.corner2[1]);
    }

    int maxZ() {
        return Math.max(this.corner1[2], this.corner2[2]);
    }

    int sizeX() {
        return this.maxX() - this.minX() + 1;
    }

    int sizeY() {
        return this.maxY() - this.minY() + 1;
    }

    int sizeZ() {
        return this.maxZ() - this.minZ() + 1;
    }

    boolean contains(Location loc) {
        if (!this.isComplete()) {
            return false;
        }
        if (loc.getWorld() == null || !loc.getWorld().getName().equals(this.world)) {
            return false;
        }
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();
        return x >= this.minX() && x <= this.maxX() && y >= this.minY() && y <= this.maxY() && z >= this.minZ() && z <= this.maxZ();
    }

    static String fmt(int[] c) {
        return c == null ? "non impostato" : c[0] + ", " + c[1] + ", " + c[2];
    }
}

