package io.github.mikaelzer0.violentsprint;

import org.bukkit.command.CommandSender;

final class Msg {
    static final String PREFIX = "\u00a78[\u00a76ViolentSprint\u00a78] \u00a7r";

    private Msg() {
    }

    static void send(CommandSender to, String message) {
        to.sendMessage(PREFIX + message);
    }
}

