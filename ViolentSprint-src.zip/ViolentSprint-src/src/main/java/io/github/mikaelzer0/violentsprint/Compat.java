package io.github.mikaelzer0.violentsprint;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.EnumSet;
import java.util.Set;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;

final class Compat {
    static final Particle P_BLOCK = Compat.particle("BLOCK", "BLOCK_CRACK");
    static final Particle P_BLOCK_CRUMBLE = Compat.particle("BLOCK_CRUMBLE", "BLOCK_DUST", "BLOCK", "BLOCK_CRACK");
    static final Particle P_CRIT = Compat.particle("CRIT");
    static final Particle P_FLAME = Compat.particle("FLAME");
    static final Particle P_CLOUD = Compat.particle("CLOUD");
    static final Particle P_FLASH = Compat.particle("FLASH");
    static final Particle P_ENCHANTED_HIT = Compat.particle("ENCHANTED_HIT", "CRIT_MAGIC");
    static final Sound S_EXPLODE = Compat.sound("ENTITY_GENERIC_EXPLODE", "EXPLODE");
    static final Sound S_FALLBACK_BREAK = Compat.sound("BLOCK_STONE_BREAK", "DIG_STONE");
    private static final Method GET_HARDNESS = Compat.findMethod(Material.class, "getHardness", new Class[0]);
    private static final Method GET_SOUND_GROUP = Compat.findMethod(BlockData.class, "getSoundGroup", new Class[0]);
    private static Method getBreakSound;
    static final boolean DISPLAY_SUPPORTED;
    private static final Method SET_PERSISTENT;
    private static Class<? extends Entity> blockDisplayClass;
    private static Method setBlock;
    private static Method setBillboard;
    private static Method setTransformation;
    private static Object billboardFixed;
    private static Constructor<?> vec3Ctor;
    private static Constructor<?> axisCtor;
    private static Constructor<?> transformCtor;

    private Compat() {
    }

    private static Object constant(Class<?> cls, String ... names) {
        for (String n : names) {
            try {
                Object o = cls.getField(n).get(null);
                if (o == null) continue;
                return o;
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
        return null;
    }

    static Particle particle(String ... names) {
        return (Particle)Compat.constant(Particle.class, names);
    }

    static Sound sound(String ... names) {
        return (Sound)Compat.constant(Sound.class, names);
    }

    static Set<Material> unbreakableMaterials() {
        String[] names = new String[]{"BEDROCK", "BARRIER", "COMMAND_BLOCK", "CHAIN_COMMAND_BLOCK", "REPEATING_COMMAND_BLOCK", "STRUCTURE_BLOCK", "STRUCTURE_VOID", "JIGSAW", "SPAWNER", "END_PORTAL_FRAME", "END_PORTAL", "END_GATEWAY", "NETHER_PORTAL", "LIGHT", "REINFORCED_DEEPSLATE", "CRAFTER_TEST_BLOCK"};
        EnumSet<Material> set = EnumSet.noneOf(Material.class);
        for (String n : names) {
            Material m = Material.getMaterial((String)n);
            if (m == null) continue;
            set.add(m);
        }
        return set;
    }

    static boolean isAir(Material type) {
        String n = type.name();
        return n.equals("AIR") || n.endsWith("_AIR");
    }

    static float hardness(Material type) {
        if (GET_HARDNESS == null) {
            return 1.0f;
        }
        try {
            return ((Float)GET_HARDNESS.invoke((Object)type, new Object[0])).floatValue();
        }
        catch (Throwable t) {
            return 1.0f;
        }
    }

    private static Method findMethod(Class<?> c, String name, Class<?> ... params) {
        try {
            return c.getMethod(name, params);
        }
        catch (Throwable t) {
            return null;
        }
    }

    static Sound breakSound(BlockData data) {
        try {
            Object group;
            if (GET_SOUND_GROUP != null && (group = GET_SOUND_GROUP.invoke((Object)data, new Object[0])) != null) {
                Object s;
                if (getBreakSound == null) {
                    getBreakSound = Class.forName("org.bukkit.SoundGroup").getMethod("getBreakSound", new Class[0]);
                }
                if ((s = getBreakSound.invoke(group, new Object[0])) != null) {
                    return (Sound)s;
                }
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return S_FALLBACK_BREAK;
    }

    static void play(World world, Location loc, Sound sound, float volume, float pitch) {
        if (sound != null) {
            world.playSound(loc, sound, volume, pitch);
        }
    }

    static void particle(World world, Particle p, Location loc, int count, double dx, double dy, double dz, double extra) {
        Compat.spawn(world, p, loc, count, dx, dy, dz, extra, null);
    }

    static void particle(World world, Particle p, Location loc, int count, double dx, double dy, double dz, double extra, BlockData data) {
        Compat.spawn(world, p, loc, count, dx, dy, dz, extra, data);
    }

    private static void spawn(World world, Particle p, Location loc, int count, double dx, double dy, double dz, double extra, BlockData blockData) {
        if (p == null) {
            return;
        }
        try {
            Object data;
            Class type = p.getDataType();
            if (type == null || type == Void.class) {
                data = null;
            } else if (type == BlockData.class) {
                data = blockData != null ? blockData : Material.STONE.createBlockData();
            } else if (type == Color.class) {
                data = Color.WHITE;
            } else {
                return;
            }
            world.spawnParticle(p, loc, count, dx, dy, dz, extra, (Object)data);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    static boolean holdsSpear(LivingEntity entity) {
        try {
            EntityEquipment eq = entity.getEquipment();
            if (eq == null) {
                return false;
            }
            ItemStack item = eq.getItemInMainHand();
            return item != null && item.getType().name().endsWith("_SPEAR");
        }
        catch (Throwable t) {
            return false;
        }
    }

    private static boolean initDisplay() {
        try {
            ClassLoader cl = Compat.class.getClassLoader();
            blockDisplayClass = (Class<? extends Entity>) Class.forName("org.bukkit.entity.BlockDisplay", true, cl);
            Class<?> billboard = Class.forName("org.bukkit.entity.Display$Billboard", true, cl);
            Class<?> transformation = Class.forName("org.bukkit.util.Transformation", true, cl);
            Class<?> vec3 = Class.forName("org.joml.Vector3f", true, cl);
            Class<?> axis = Class.forName("org.joml.AxisAngle4f", true, cl);
            setBlock = blockDisplayClass.getMethod("setBlock", BlockData.class);
            setBillboard = blockDisplayClass.getMethod("setBillboard", billboard);
            setTransformation = blockDisplayClass.getMethod("setTransformation", transformation);
            billboardFixed = Enum.valueOf((Class) billboard, "FIXED");
            vec3Ctor = vec3.getConstructor(Float.TYPE, Float.TYPE, Float.TYPE);
            axisCtor = axis.getConstructor(Float.TYPE, Float.TYPE, Float.TYPE, Float.TYPE);
            transformCtor = transformation.getConstructor(vec3, axis, vec3, axis);
            return true;
        }
        catch (Throwable t) {
            return false;
        }
    }

    static Entity spawnFragment(World world, Location loc, BlockData data, float scale) {
        if (!DISPLAY_SUPPORTED) {
            return null;
        }
        try {
            Entity e = world.spawn(loc, blockDisplayClass);
            if (SET_PERSISTENT != null) {
                try {
                    SET_PERSISTENT.invoke((Object)e, false);
                }
                catch (Throwable throwable) {
                    // empty catch block
                }
            }
            setBlock.invoke((Object)e, data);
            setBillboard.invoke((Object)e, billboardFixed);
            Compat.rotateFragment(e, scale, 0.0f, 0.0f, 1.0f, 0.0f);
            return e;
        }
        catch (Throwable t) {
            return null;
        }
    }

    static void rotateFragment(Entity display, float scale, float angle, float ax, float ay, float az) {
        try {
            float half = -scale / 2.0f;
            Object translation = vec3Ctor.newInstance(Float.valueOf(half), Float.valueOf(half), Float.valueOf(half));
            Object left = axisCtor.newInstance(Float.valueOf(angle), Float.valueOf(ax), Float.valueOf(ay), Float.valueOf(az));
            Object scaleVec = vec3Ctor.newInstance(Float.valueOf(scale), Float.valueOf(scale), Float.valueOf(scale));
            Object right = axisCtor.newInstance(Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(1.0f));
            setTransformation.invoke((Object)display, transformCtor.newInstance(translation, left, scaleVec, right));
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    static {
        SET_PERSISTENT = Compat.findMethod(Entity.class, "setPersistent", Boolean.TYPE);
        DISPLAY_SUPPORTED = Compat.initDisplay();
    }
}

