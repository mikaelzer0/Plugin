package io.github.mikaelzer0.violentsprint;

import io.github.mikaelzer0.violentsprint.Compat;
import io.github.mikaelzer0.violentsprint.Msg;
import io.github.mikaelzer0.violentsprint.ViolentSprint;
import io.github.mikaelzer0.violentsprint.Zone;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

final class Menus
implements Listener {
    private static final int PAGE_SIZE = 45;
    private static final long PROMPT_TIMEOUT_MS = 60000L;
    private final ViolentSprint plugin;
    private final Map<UUID, Prompt> prompts = new ConcurrentHashMap<UUID, Prompt>();

    Menus(ViolentSprint plugin) {
        this.plugin = plugin;
    }

    private Holder create(Type type, String zone, int page, int size, String title) {
        Holder h = new Holder(type, zone, page);
        h.inventory = Bukkit.createInventory((InventoryHolder)h, (int)size, (String)title);
        return h;
    }

    private void show(Player p, Holder h) {
        this.render(h);
        p.openInventory(h.inventory);
    }

    void openMain(Player p) {
        this.show(p, this.create(Type.MAIN, null, 0, 27, "\u00a78ViolentSprint - Menu"));
    }

    void openZones(Player p, int page) {
        this.show(p, this.create(Type.ZONES, null, page, 54, "\u00a78Zone bersaglio"));
    }

    void openZone(Player p, String zoneName) {
        Zone z = this.plugin.zones.get(zoneName);
        if (z == null) {
            this.openZones(p, 0);
            return;
        }
        this.plugin.pendingZoneByPlayer.put(p.getUniqueId(), z.name);
        this.show(p, this.create(Type.ZONE, z.name, 0, 36, "\u00a78Zona: " + z.name));
    }

    void openBlocks(Player p, String zoneName, int page) {
        String title = zoneName == null ? "\u00a78Blocchi protetti: universale" : "\u00a78Blocchi: " + zoneName;
        this.show(p, this.create(Type.BLOCKS, zoneName, page, 54, title));
    }

    private void openConfirm(Player p, String zoneName) {
        this.show(p, this.create(Type.CONFIRM, zoneName, 0, 27, "\u00a78Eliminare la zona?"));
    }

    private void render(Holder h) {
        h.inventory.clear();
        h.data.clear();
        switch (h.type.ordinal()) {
            case 0: {
                this.renderMain(h);
                break;
            }
            case 1: {
                this.renderZones(h);
                break;
            }
            case 2: {
                this.renderZone(h);
                break;
            }
            case 3: {
                this.renderBlocks(h);
                break;
            }
            case 4: {
                this.renderConfirm(h);
                break;
            }
        }
        ItemStack filler = this.item(Material.GRAY_STAINED_GLASS_PANE, " ", new String[0]);
        for (int i = 0; i < h.inventory.getSize(); ++i) {
            if (h.inventory.getItem(i) != null) continue;
            h.inventory.setItem(i, filler);
        }
    }

    private void renderMain(Holder h) {
        Inventory inv = h.inventory;
        int active = 0;
        for (Zone z : this.plugin.zones.values()) {
            if (!z.enabled || !z.isComplete()) continue;
            ++active;
        }
        boolean on = this.plugin.breakEverywhere;
        inv.setItem(11, this.item(Material.COMPASS, "\u00a7aZone bersaglio", "\u00a77Zone definite: \u00a7f" + this.plugin.zones.size(), "\u00a77Zone attive e complete: \u00a7f" + active, "", "\u00a7eClick: vedi, modifica, crea, elimina"));
        inv.setItem(13, this.item(on ? Material.LIME_DYE : Material.GRAY_DYE, on ? "\u00a7aUniversale: ATTIVO" : "\u00a7cUniversale: SPENTO", "\u00a77Attivo: i colpi rompono i blocchi", "\u00a77OVUNQUE, in tutti i mondi.", "\u00a77Spento: solo dentro le zone attive.", "", "\u00a7eClick: " + (on ? "spegni" : "attiva")));
        inv.setItem(15, this.item(Material.BEDROCK, "\u00a76Blocchi protetti universali", "\u00a77Questi blocchi non si rompono mai,", "\u00a77n\u00e9 nelle zone n\u00e9 in modalit\u00e0 universale.", "\u00a77In lista: \u00a7f" + this.plugin.globalProtected.size(), "", "\u00a7eClick: modifica la lista"));
        inv.setItem(4, this.item(Material.BOOK, "\u00a76ViolentSprint " + this.plugin.getDescription().getVersion(), this.plugin.statusLines().toArray(new String[0])));
        inv.setItem(22, this.item(Material.BARRIER, "\u00a7cChiudi", new String[0]));
    }

    private ItemStack zoneItem(Zone z) {
        String stato;
        Material icon;
        if (!z.isComplete()) {
            icon = Material.YELLOW_CONCRETE;
            stato = "\u00a7eincompleta (manca un angolo)";
        } else if (!z.enabled) {
            icon = Material.RED_CONCRETE;
            stato = "\u00a7cdisattivata";
        } else {
            icon = Material.LIME_CONCRETE;
            stato = "\u00a7aattiva";
        }
        ArrayList<String> lore = new ArrayList<String>();
        lore.add("\u00a77Mondo: \u00a7f" + z.world);
        lore.add("\u00a77Stato: " + stato);
        if (z.isComplete()) {
            lore.add("\u00a77Dimensioni: \u00a7f" + z.sizeX() + "x" + z.sizeY() + "x" + z.sizeZ());
        }
        lore.add("\u00a77Blocchi protetti: \u00a7f" + z.protectedBlocks.size());
        lore.add("");
        lore.add("\u00a7eClick: apri e modifica");
        return this.item(icon, "\u00a7f" + z.name, lore.toArray(new String[0]));
    }

    private void renderZones(Holder h) {
        Inventory inv = h.inventory;
        ArrayList<Zone> list = new ArrayList<Zone>(this.plugin.zones.values());
        int pages = Math.max(1, (list.size() + 45 - 1) / 45);
        h.page = Math.max(0, Math.min(h.page, pages - 1));
        int start = h.page * 45;
        for (int i = 0; i < 45 && start + i < list.size(); ++i) {
            Zone z = (Zone)list.get(start + i);
            inv.setItem(i, this.zoneItem(z));
            h.data.put(i, z.name);
        }
        if (list.isEmpty()) {
            inv.setItem(22, this.item(Material.PAPER, "\u00a77Nessuna zona definita", "\u00a77Usa \"Nuova zona\" qui sotto."));
        }
        inv.setItem(45, this.item(Material.ARROW, "\u00a7eIndietro", new String[0]));
        if (h.page > 0) {
            inv.setItem(47, this.item(Material.ARROW, "\u00a77Pagina precedente", new String[0]));
        }
        inv.setItem(49, this.item(Material.EMERALD, "\u00a7aNuova zona", "\u00a77Ti chiedo il nome in chat."));
        if (h.page < pages - 1) {
            inv.setItem(51, this.item(Material.ARROW, "\u00a77Pagina successiva", new String[0]));
        }
        inv.setItem(53, this.item(Material.PAPER, "\u00a77Pagina " + (h.page + 1) + "/" + pages, new String[0]));
    }

    private void renderZone(Holder h) {
        Inventory inv = h.inventory;
        Zone z = this.plugin.zones.get(h.zone);
        if (z == null) {
            return;
        }
        ArrayList<String> info = new ArrayList<String>();
        info.add("\u00a77Mondo: \u00a7f" + z.world);
        info.add("\u00a77Angolo 1: \u00a7f" + Zone.fmt(z.corner1));
        info.add("\u00a77Angolo 2: \u00a7f" + Zone.fmt(z.corner2));
        if (z.isComplete()) {
            info.add("\u00a77Dimensioni: \u00a7f" + z.sizeX() + "x" + z.sizeY() + "x" + z.sizeZ());
            info.add("\u00a77Blocchi totali: \u00a7f" + (long)z.sizeX() * (long)z.sizeY() * (long)z.sizeZ());
        } else {
            info.add("\u00a7eZona incompleta: imposta entrambi gli angoli.");
        }
        info.add("\u00a77Blocchi protetti: \u00a7f" + z.protectedBlocks.size());
        inv.setItem(4, this.item(Material.PAPER, "\u00a76Zona " + z.name, info.toArray(new String[0])));
        inv.setItem(10, this.item(Material.TORCH, "\u00a7aImposta angolo 1 qui", "\u00a77Usa il blocco dove sei ora.", "\u00a77Attuale: \u00a7f" + Zone.fmt(z.corner1)));
        inv.setItem(12, this.item(Material.REDSTONE_TORCH, "\u00a7aImposta angolo 2 qui", "\u00a77Usa il blocco dove sei ora.", "\u00a77Attuale: \u00a7f" + Zone.fmt(z.corner2)));
        inv.setItem(14, this.item(Material.ENDER_EYE, "\u00a7bMostra i confini", "\u00a77Disegna il contorno con delle particelle", "\u00a77per qualche secondo (solo per te)."));
        inv.setItem(16, this.item(Material.ENDER_PEARL, "\u00a7dTeletrasportati qui", "\u00a77Ti porta al centro della zona."));
        inv.setItem(20, this.item(z.enabled ? Material.LIME_DYE : Material.GRAY_DYE, z.enabled ? "\u00a7aZona ATTIVA" : "\u00a7cZona DISATTIVATA", "\u00a77Una zona disattivata resta salvata", "\u00a77ma non rompe nulla.", "", "\u00a7eClick: " + (z.enabled ? "disattiva" : "attiva")));
        inv.setItem(22, this.item(Material.OBSIDIAN, "\u00a76Blocchi protetti della zona", "\u00a77Non si rompono dentro questa zona.", "\u00a77In lista: \u00a7f" + z.protectedBlocks.size(), "", "\u00a7eClick: modifica la lista"));
        inv.setItem(24, this.item(Material.NAME_TAG, "\u00a7eRinomina", "\u00a77Ti chiedo il nuovo nome in chat."));
        inv.setItem(26, this.item(Material.TNT, "\u00a7cElimina la zona", "\u00a77Ti chiedo conferma."));
        inv.setItem(31, this.item(Material.ARROW, "\u00a7eTorna alla lista zone", new String[0]));
    }

    private void renderConfirm(Holder h) {
        Inventory inv = h.inventory;
        inv.setItem(11, this.item(Material.LIME_CONCRETE, "\u00a7aSI, elimina", "\u00a77Zona: \u00a7f" + h.zone, "\u00a7cNon si pu\u00f2 annullare."));
        inv.setItem(13, this.item(Material.PAPER, "\u00a76Eliminare '" + h.zone + "'?", new String[0]));
        inv.setItem(15, this.item(Material.RED_CONCRETE, "\u00a7cNo, annulla", new String[0]));
    }

    private Set<Material> blockSet(Holder h) {
        if (h.zone == null) {
            return this.plugin.globalProtected;
        }
        Zone z = this.plugin.zones.get(h.zone);
        return z == null ? null : z.protectedBlocks;
    }

    private void renderBlocks(Holder h) {
        Inventory inv = h.inventory;
        Set<Material> set = this.blockSet(h);
        if (set == null) {
            return;
        }
        ArrayList<Material> list = new ArrayList<Material>(set);
        Collections.sort(list, (a, b) -> a.name().compareTo(b.name()));
        int pages = Math.max(1, (list.size() + 45 - 1) / 45);
        h.page = Math.max(0, Math.min(h.page, pages - 1));
        int start = h.page * 45;
        for (int i = 0; i < 45 && start + i < list.size(); ++i) {
            Material m = (Material)list.get(start + i);
            Material icon = m.isItem() ? m : Material.BARRIER;
            inv.setItem(i, this.item(icon, "\u00a7f" + m.name(), "\u00a7eClick: rimuovi dalla lista"));
            h.data.put(i, m.name());
        }
        if (list.isEmpty()) {
            inv.setItem(22, this.item(Material.PAPER, "\u00a77Nessun blocco protetto", new String[0]));
        }
        inv.setItem(45, this.item(Material.ARROW, "\u00a7eIndietro", new String[0]));
        if (h.page > 0) {
            inv.setItem(47, this.item(Material.ARROW, "\u00a77Pagina precedente", new String[0]));
        }
        inv.setItem(49, this.item(Material.PAPER, "\u00a7aCome aggiungere un blocco", "\u00a77Clicca un blocco nel TUO inventario", "\u00a77(la parte bassa) per aggiungerlo.", "\u00a77Clicca un blocco in lista per toglierlo.", "\u00a77Oppure: /vs ... block add <MATERIALE>"));
        if (h.page < pages - 1) {
            inv.setItem(51, this.item(Material.ARROW, "\u00a77Pagina successiva", new String[0]));
        }
        inv.setItem(53, this.item(Material.LAVA_BUCKET, "\u00a7cSvuota la lista", "\u00a77Rimuove tutti i blocchi protetti."));
    }

    private ItemStack item(Material m, String name, String ... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            if (lore.length > 0) {
                meta.setLore(Arrays.asList(lore));
            }
            it.setItemMeta(meta);
        }
        return it;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getInventory();
        if (!(top.getHolder() instanceof Holder)) {
            return;
        }
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player)) {
            return;
        }
        Player p = (Player)e.getWhoClicked();
        if (!ViolentSprint.isAdmin((CommandSender)p)) {
            p.closeInventory();
            return;
        }
        Holder h = (Holder)top.getHolder();
        Inventory clicked = e.getClickedInventory();
        if (clicked == null) {
            return;
        }
        if (clicked != top) {
            if (h.type == Type.BLOCKS) {
                this.addFromItem(p, h, e.getCurrentItem());
            }
            return;
        }
        this.onTopClick(p, h, e.getSlot());
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) {
            e.setCancelled(true);
        }
    }

    private void onTopClick(Player p, Holder h, int slot) {
        switch (h.type.ordinal()) {
            case 0: {
                this.clickMain(p, h, slot);
                break;
            }
            case 1: {
                this.clickZones(p, h, slot);
                break;
            }
            case 2: {
                this.clickZone(p, h, slot);
                break;
            }
            case 3: {
                this.clickBlocks(p, h, slot);
                break;
            }
            case 4: {
                this.clickConfirm(p, h, slot);
                break;
            }
        }
    }

    private void clickMain(Player p, Holder h, int slot) {
        switch (slot) {
            case 11: {
                this.openZones(p, 0);
                break;
            }
            case 13: {
                this.plugin.setBreakEverywhere((CommandSender)p, !this.plugin.breakEverywhere);
                this.render(h);
                p.updateInventory();
                break;
            }
            case 15: {
                this.openBlocks(p, null, 0);
                break;
            }
            case 22: {
                p.closeInventory();
                break;
            }
        }
    }

    private void clickZones(Player p, Holder h, int slot) {
        String zoneName = h.data.get(slot);
        if (zoneName != null) {
            this.openZone(p, zoneName);
            return;
        }
        switch (slot) {
            case 45: {
                this.openMain(p);
                break;
            }
            case 47: {
                if (h.page <= 0) break;
                --h.page;
                this.render(h);
                p.updateInventory();
                break;
            }
            case 51: {
                ++h.page;
                this.render(h);
                p.updateInventory();
                break;
            }
            case 49: {
                p.closeInventory();
                this.prompts.put(p.getUniqueId(), new Prompt(PromptType.NEW_ZONE, null));
                Msg.send((CommandSender)p, "\u00a76Scrivi in chat il nome della nuova zona \u00a77(minuscole, numeri, - e _, max 20 caratteri).");
                Msg.send((CommandSender)p, "\u00a77Scrivi \u00a7fannulla\u00a77 per tornare indietro.");
                break;
            }
        }
    }

    private void clickZone(Player p, Holder h, int slot) {
        Zone z = this.plugin.zones.get(h.zone);
        if (z == null) {
            this.openZones(p, 0);
            return;
        }
        switch (slot) {
            case 10: 
            case 12: {
                int idx = slot == 10 ? 1 : 2;
                String err = this.plugin.setCorner(z, idx, p.getLocation());
                if (err != null) {
                    Msg.send((CommandSender)p, "\u00a7c" + err);
                } else {
                    Msg.send((CommandSender)p, "\u00a7aAngolo " + idx + " di '" + z.name + "' impostato.");
                    if (z.isComplete()) {
                        Msg.send((CommandSender)p, "\u00a76Zona '" + z.name + "' completa!");
                    }
                }
                this.render(h);
                p.updateInventory();
                break;
            }
            case 14: {
                this.showBorders(p, z);
                break;
            }
            case 16: {
                this.teleport(p, z);
                break;
            }
            case 20: {
                z.enabled = !z.enabled;
                this.plugin.saveZonesConfig();
                this.plugin.audit((CommandSender)p, "zona '" + z.name + "' " + (z.enabled ? "attivata" : "disattivata"));
                this.render(h);
                p.updateInventory();
                break;
            }
            case 22: {
                this.openBlocks(p, z.name, 0);
                break;
            }
            case 24: {
                p.closeInventory();
                this.prompts.put(p.getUniqueId(), new Prompt(PromptType.RENAME_ZONE, z.name));
                Msg.send((CommandSender)p, "\u00a76Scrivi in chat il nuovo nome per '" + z.name + "'.");
                Msg.send((CommandSender)p, "\u00a77Scrivi \u00a7fannulla\u00a77 per tornare indietro.");
                break;
            }
            case 26: {
                this.openConfirm(p, z.name);
                break;
            }
            case 31: {
                this.openZones(p, 0);
                break;
            }
        }
    }

    private void clickConfirm(Player p, Holder h, int slot) {
        if (slot == 11) {
            String err = this.plugin.deleteZone(h.zone);
            if (err == null) {
                this.plugin.audit((CommandSender)p, "zona '" + h.zone + "' eliminata");
            }
            Msg.send((CommandSender)p, err == null ? "\u00a7aZona '" + h.zone + "' eliminata." : "\u00a7c" + err);
            this.openZones(p, 0);
        } else if (slot == 15) {
            this.openZone(p, h.zone);
        }
    }

    private void clickBlocks(Player p, Holder h, int slot) {
        Set<Material> set = this.blockSet(h);
        if (set == null) {
            this.openZones(p, 0);
            return;
        }
        String matName = h.data.get(slot);
        if (matName != null) {
            Material m = Material.getMaterial((String)matName);
            if (m != null) {
                set.remove(m);
                this.plugin.saveZonesConfig();
            }
            this.render(h);
            p.updateInventory();
            return;
        }
        switch (slot) {
            case 45: {
                if (h.zone == null) {
                    this.openMain(p);
                    break;
                }
                this.openZone(p, h.zone);
                break;
            }
            case 47: {
                if (h.page <= 0) break;
                --h.page;
                this.render(h);
                p.updateInventory();
                break;
            }
            case 51: {
                ++h.page;
                this.render(h);
                p.updateInventory();
                break;
            }
            case 53: {
                set.clear();
                this.plugin.saveZonesConfig();
                this.plugin.audit((CommandSender)p, "lista blocchi protetti (" + (h.zone == null ? "universale" : "zona " + h.zone) + ") svuotata");
                this.render(h);
                p.updateInventory();
                break;
            }
        }
    }

    private void addFromItem(Player p, Holder h, ItemStack stack) {
        if (stack == null || stack.getType() == Material.AIR) {
            return;
        }
        Set<Material> set = this.blockSet(h);
        if (set == null) {
            return;
        }
        Material m = stack.getType();
        if (!m.isBlock() || Compat.isAir(m)) {
            Msg.send((CommandSender)p, "\u00a7cQuello non \u00e8 un blocco.");
            return;
        }
        if (set.add(m)) {
            this.plugin.saveZonesConfig();
            Msg.send((CommandSender)p, "\u00a7aAggiunto \u00a7f" + m.name() + "\u00a7a alla lista.");
        } else {
            Msg.send((CommandSender)p, "\u00a77" + m.name() + " \u00e8 gi\u00e0 in lista.");
        }
        this.render(h);
        p.updateInventory();
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent e) {
        if (this.prompts.isEmpty()) {
            return;
        }
        Prompt prompt = this.prompts.remove(e.getPlayer().getUniqueId());
        if (prompt == null) {
            return;
        }
        if (prompt.expired() || !ViolentSprint.isAdmin((CommandSender)e.getPlayer())) {
            return;
        }
        e.setCancelled(true);
        Player p = e.getPlayer();
        String msg = e.getMessage().trim();
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.handlePrompt(p, prompt, msg));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        this.prompts.remove(e.getPlayer().getUniqueId());
    }

    private void handlePrompt(Player p, Prompt prompt, String msg) {
        if (msg.equalsIgnoreCase("annulla") || msg.equalsIgnoreCase("cancel")) {
            Msg.send((CommandSender)p, "\u00a77Annullato.");
            if (prompt.type == PromptType.NEW_ZONE) {
                this.openZones(p, 0);
            } else {
                this.openZone(p, prompt.zone);
            }
            return;
        }
        if (prompt.type == PromptType.NEW_ZONE) {
            String err = this.plugin.createZone(msg, p.getWorld().getName());
            if (err != null) {
                Msg.send((CommandSender)p, "\u00a7c" + err + " \u00a77Riprova oppure scrivi \u00a7fannulla\u00a77.");
                this.prompts.put(p.getUniqueId(), prompt);
                return;
            }
            String name = msg.toLowerCase(Locale.ROOT);
            this.plugin.audit((CommandSender)p, "zona '" + name + "' creata");
            Msg.send((CommandSender)p, "\u00a7aZona '" + name + "' creata. Ora imposta i due angoli da questo menu.");
            this.openZone(p, name);
        } else {
            Zone z = this.plugin.zones.get(prompt.zone);
            if (z == null) {
                this.openZones(p, 0);
                return;
            }
            String err = this.plugin.renameZone(z, msg);
            if (err != null) {
                Msg.send((CommandSender)p, "\u00a7c" + err + " \u00a77Riprova oppure scrivi \u00a7fannulla\u00a77.");
                this.prompts.put(p.getUniqueId(), prompt);
                return;
            }
            Msg.send((CommandSender)p, "\u00a7aZona rinominata in '" + z.name + "'.");
            this.openZone(p, z.name);
        }
    }

    void teleport(Player p, Zone z) {
        if (!z.isComplete()) {
            Msg.send((CommandSender)p, "\u00a7cLa zona '" + z.name + "' \u00e8 incompleta.");
            return;
        }
        World w = Bukkit.getWorld((String)z.world);
        if (w == null) {
            Msg.send((CommandSender)p, "\u00a7cIl mondo '" + z.world + "' non \u00e8 caricato.");
            return;
        }
        double cx = (double)(z.minX() + z.maxX()) / 2.0 + 0.5;
        double cz = (double)(z.minZ() + z.maxZ()) / 2.0 + 0.5;
        int y = w.getHighestBlockYAt((int)Math.floor(cx), (int)Math.floor(cz)) + 1;
        p.teleport(new Location(w, cx, (double)y, cz));
        Msg.send((CommandSender)p, "\u00a7aTeletrasportato al centro di '" + z.name + "'.");
    }

    void showBorders(final Player p, Zone z) {
        if (!z.isComplete()) {
            Msg.send((CommandSender)p, "\u00a7cLa zona '" + z.name + "' \u00e8 incompleta: imposta entrambi gli angoli.");
            return;
        }
        World w = Bukkit.getWorld((String)z.world);
        if (w == null || !p.getWorld().equals((Object)w)) {
            Msg.send((CommandSender)p, "\u00a7cDevi essere nel mondo '" + z.world + "' per vedere i confini.");
            return;
        }
        final Particle flame = Compat.P_FLAME;
        if (flame == null) {
            Msg.send((CommandSender)p, "\u00a7cParticelle non disponibili su questa versione.");
            return;
        }
        final List<Location> points = this.edgePoints(w, z.minX(), z.minY(), z.minZ(), (double)z.maxX() + 1.0, (double)z.maxY() + 1.0, (double)z.maxZ() + 1.0);
        Msg.send((CommandSender)p, "\u00a7bConfini di '" + z.name + "' mostrati per qualche secondo.");
        new BukkitRunnable(){
            int runs = 0;

            public void run() {
                if (!p.isOnline() || this.runs++ >= 12) {
                    this.cancel();
                    return;
                }
                for (Location l : points) {
                    p.spawnParticle(flame, l, 1, 0.0, 0.0, 0.0, 0.0);
                }
            }
        }.runTaskTimer((Plugin)this.plugin, 0L, 10L);
    }

    private List<Location> edgePoints(World w, double x0, double y0, double z0, double x1, double y1, double z1) {
        double totalLength = 4.0 * (x1 - x0 + (y1 - y0) + (z1 - z0));
        double step = Math.max(0.5, totalLength / 300.0);
        ArrayList<Location> pts = new ArrayList<Location>();
        double[] ys = new double[]{y0, y1};
        double[] zs = new double[]{z0, z1};
        double[] xs = new double[]{x0, x1};
        for (double y : ys) {
            for (double z : zs) {
                this.addEdge(pts, w, x0, y, z, x1, y, z, step);
            }
        }
        for (double x : xs) {
            for (double z : zs) {
                this.addEdge(pts, w, x, y0, z, x, y1, z, step);
            }
        }
        for (double x : xs) {
            for (double y : ys) {
                this.addEdge(pts, w, x, y, z0, x, y, z1, step);
            }
        }
        return pts;
    }

    private void addEdge(List<Location> pts, World w, double ax, double ay, double az, double bx, double by, double bz, double step) {
        double dx = bx - ax;
        double dy = by - ay;
        double dz = bz - az;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        int n = Math.max(1, (int)Math.ceil(len / step));
        for (int i = 0; i <= n; ++i) {
            double t = (double)i / (double)n;
            pts.add(new Location(w, ax + dx * t, ay + dy * t, az + dz * t));
        }
    }

    private static final class Holder
    implements InventoryHolder {
        final Type type;
        final String zone;
        int page;
        final Map<Integer, String> data = new HashMap<Integer, String>();
        Inventory inventory;

        Holder(Type type, String zone, int page) {
            this.type = type;
            this.zone = zone;
            this.page = page;
        }

        public Inventory getInventory() {
            return this.inventory;
        }
    }

    private static enum Type {
        MAIN,
        ZONES,
        ZONE,
        BLOCKS,
        CONFIRM;

    }

    private static final class Prompt {
        final PromptType type;
        final String zone;
        final long created = System.currentTimeMillis();

        Prompt(PromptType type, String zone) {
            this.type = type;
            this.zone = zone;
        }

        boolean expired() {
            return System.currentTimeMillis() - this.created > 60000L;
        }
    }

    private static enum PromptType {
        NEW_ZONE,
        RENAME_ZONE;

    }
}

