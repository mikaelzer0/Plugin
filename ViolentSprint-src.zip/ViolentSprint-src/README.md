# ViolentSprint

Plugin Spigot/Paper (1.13+): il knockback e gli impatti forti sfondano i blocchi dentro le zone bersaglio o ovunque, con blocchi protetti e rigenerazione automatica.

Autore: mikaelzer0 — https://github.com/mikaelzer0

## Compilare
```
mvn clean package
```
Il jar esce in `target/ViolentSprint.jar` (Java 8+, API Spigot 1.13.2).

## Comandi
`/vs [menu|zone|universal|status|reload|help]`, `/row`, `/tcreate`, `/t1`, `/t2`, `/tlist`, `/tremove` — permesso `violentsprint.admin` (default: OP).

## Note
Sorgenti recuperati dal jar con un decompilatore: i nomi di variabili locali e i commenti originali non ci sono.
